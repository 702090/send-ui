// Utility for setting chunk paths for different environments and domain (MCC)

const getFileName = (isDevelop, isProduction, isStage, version) => {
    if (isDevelop) {
        return 'static/js/bundle.js'
    }

    switch (isProduction) {
        case isStage:
            return `grip/${version}/static/js/[name].[contenthash:8].js`
        default:
            return `grip/${version}/static/js/[name].[contenthash:8].js`
    }
}

const getChunkFileName = (isDevelop, isProduction, isStage, version) => {
    if (isDevelop) {
        return 'static/js/[name].chunk.js'
    }

    switch (isProduction) {
        case isStage:
            return `grip/${version}/static/js/[name].[contenthash:8].chunk.js`
        default:
            return `grip/${version}/static/js/[name].[contenthash:8].chunk.js`
    }
}

const getMinifyCSSPlugin = (isProduction, isStage, version) => {
    if (isStage && isProduction) {
        return {
            filename: `grip/${version}/static/css/[name].[contenthash:8].css`,
            chunkFilename:
                `grip/${version}/static/css/[name].[contenthash:8].chunk.css`,
        }
    } else {
        return {
            filename: `grip/${version}/static/css/[name].[contenthash:8].css`,
            chunkFilename:
                `grip/${version}/static/css/[name].[contenthash:8].chunk.css`,
        }
    }
}

module.exports = {
    getChunkFileName,
    getFileName,
    getMinifyCSSPlugin,
}
