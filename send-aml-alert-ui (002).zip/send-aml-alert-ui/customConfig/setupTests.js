import '@testing-library/jest-dom'
import { enableFetchMocks } from 'jest-fetch-mock'
enableFetchMocks()

// Jest uses JSDOM. JSDOM does not have matchMedia.
// Mocking matchMedia to allow tinymce test cases run
Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: jest.fn().mockImplementation((query) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: jest.fn(),
        removeListener: jest.fn(),
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn(),
    })),
})
