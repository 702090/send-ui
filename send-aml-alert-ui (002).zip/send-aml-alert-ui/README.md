Network Guardian Tool (MVP)

MVP enhancements to the Anti-Money Laundering (AML) Cube solution streamlines Mastercard’s process to detect fraud.

# Development

## Environment setup

In order to develop this application you will need these things:

- NodeJS
  - You can get the latest available from Mastercard. This should come with npm automatically.
- IDE
  - I highly suggest `Visual Studio Code` from the software center.

You should setup your environment by following the below steps.

We need to set the registry because when the application is built with Jenkins it only has access to the libraries in artifactory, so you need to make sure dependencies are in there while developing.

```bash
# Set the node package manager to look at Mastercard's artifactory.
npm config set registry https://artifacts.mastercard.int/artifactory/api/npm/npm-all/

# Remove SSL Errors
npm config set strict-ssl false
```

### Sonar Lint

For Quality purposes you should install the sonar plugin for your ide. For VSCode you can use the below instructions for set up.

[SonarQube Project](https://fusion.mastercard.int/sonar/dashboard?id=send-aml-alert-ui)

Install `SonarLint` Extension.

Open Settings and search for `@ext:sonarsource.sonarlint-vscode`

```json
"sonarlint.connectedMode.connections.sonarqube": [
    {
        "connectionId": "MCSonarQube",
        "serverUrl": "http://fusion.mastercard.int/sonar",
        "token": "GET_TOKEN_FROM_USER_PROFILE"
    }
],
```

You may have to add this to your user settings to direct Sonar to your installed java instance

```json
"sonarlint.ls.javaHome": "C:\\\\Program Files\\\\Java\\\\jdk1.8.X_XXX",
```

## Run For Development

After you've completed those steps, your machine is setup to run the React application.

1. `git clone https://fusion.mastercard.int/stash/scm/ngt_fls/ngt_self_service_ui.git`
2. `cd ngt_self_service_ui`
3. `npm install`
4. `npm start`

## Run For Testing

While developing, you should have a separate console window open to have your tests.

Running the command below will run the tests in "watch" mode, so anytime you save a file, it'll run the tests for the components that were affected by your edits.

```bash
npm test
```

## Production Build

After a react application is built, the `./build/` folder can be copied to any webserver that serves static files.

to create a production build:

```bash
npm run build
```

## Running Tests

[Official React Scripts Documentation](https://create-react-app.dev/docs/running-tests)

### Deployment Commands

For Linux:

```bash
CI=true npm test
CI=true npm run build
```

### Local Testing

- To run all the tests, run `npm test`, it will start in watch mode and rerun on file updates.

- To run coverage on all files `npm run fullCoverage`

- To run it without watch `npm test --watchAll=false`

- To run a coverage analysis and report `npm test -- --coverage`

### Disable / Focus Tests

- To Exclude a Test from running, Change `it()` to `xit()`
- To 'focus' on specific tests running, Change `it()` to `fit()`

### Install Jest Extension in VS Code

[GitHub](https://github.com/jest-community/vscode-jest)

## Writing Tests

### Overview

Currently we are working to write fewer, but still thorough integration tests.

This application uses these libraries for testing

- Jest
- react-testing-library
- mock-service-worker

`SetupTests.js` is basically a wrapper to any test in the project. Anything you want to run every test, you put in here.

### Mock Rest Calls

#### src/mocks/

- `server.js` sets up the mock server with handlers. Likely won't need to be changed.
- `handlers.js` These are the handlers registered to overwrite when a rest call is made.
  - As you test rest components, add to this file.

If you need the same endpoint to react differently per test:

- Create a generic endpoint in this file for the base case.
- in individual tests you can overwrite the handler in the same way.

```javascript
rest.get('https://mastercard.com/ssrs/*', (req, res, ctx) => {
    return res.networkError('Failed to Connect');
}),
```

Notice in `setupTests.js`

```javascript
import '@testing-library/jest-dom/extend-expect';
import { server } from './mocks/server.js';

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
```

### Mock URL Parameters

See `SSRSReportPages.integration.test.js` for implementing mock parameters / url structure

```javascript
function mockUseLocation() {
  const original = require.requireActual('react-router-dom');
  return {
    ...original,
    useLocation: jest.fn().mockReturnValue({
      pathname: '/another-route',
      search: '?AlertYear=2010',
      hash: '',
      state: null,
      key: '5nvxpbdafa',
    }),
  };
}

jest.mock('react-router-dom', () => mockUseLocation());
```
