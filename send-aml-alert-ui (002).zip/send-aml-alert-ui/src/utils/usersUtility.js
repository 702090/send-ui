export const sortUsersByFullName = (listOfUsers) => {
  listOfUsers.sort(function (userDetails1, userDetails2) {
    const x = concatFullName(userDetails1).toLowerCase()
    const y = concatFullName(userDetails2).toLowerCase()
    return x < y ? -1 : x > y ? 1 : 0
  })
}

export const concatFullName = (userDetails) => {
  return `${nullCheck(userDetails.firstname)} ${nullCheck(
    userDetails.lastname
  )}`
}

export const nullCheck = (value) => {
  if (!value) {
    return ''
  }
  return value.trim()
}

export const getUserId = (listOfUsers, value) => {
  if (listOfUsers.length > 0) {
    return listOfUsers.find(
      (userDetails) => concatFullName(userDetails) === value
    )?.eid
  }
}
