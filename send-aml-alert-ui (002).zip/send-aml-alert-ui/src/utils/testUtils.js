import React from 'react'
import { render as rtlRender } from '@testing-library/react'
import { createMemoryHistory } from 'history'
import { Router } from 'react-router-dom'
import { Provider } from 'react-redux'
import thunk from 'redux-thunk'
import configureMockStore from 'redux-mock-store'
import alertLists from '../__mocks__/alertList'
import store from '../store'
import { defaultAlertListColDef } from './columnDefinitions'

const mockStore = configureMockStore([thunk])

const history = createMemoryHistory()

const initialHistory = createMemoryHistory({ initialEntries: ['/'] })

const renderWithProvider = ({ children }) => {
  return <Provider store={store}>{children}</Provider>
}

const renderWithRouter = ({ children }) => {
  return <Router history={history}>{children}</Router>
}

const renderWithProviderRouter = ({ children }) => {
  return (
    <Provider store={store}>
      <Router history={history}>{children}</Router>
    </Provider>
  )
}

const customRenderWithProvider = (ui, options) =>
  rtlRender(ui, { wrapper: renderWithProvider, ...options })

const customRenderWithRouter = (ui, options) =>
  rtlRender(ui, { wrapper: renderWithRouter, ...options })

const customRenderWithProviderRouter = (ui, options) =>
  rtlRender(ui, { wrapper: renderWithProviderRouter, ...options })

const render = (ui, { store, history, ...options } = {}) => {
  const renderWithStore = ({ children }) => {
    return (
      <Provider store={store || mockStore({})}>
        <Router history={history || initialHistory}>{children}</Router>
      </Provider>
    )
  }
  return rtlRender(ui, { wrapper: renderWithStore, ...options })
}
const alertListColumns = defaultAlertListColDef.map((i) => ({
  ...i,
  hidden: false,
}))
const testStore = {
  alertList: {
    details: alertLists,
    loading: false,
    columns: alertListColumns,
    currentAction: 'filter',
  },
  filters: {
    filtersData: [
      {
        filterName: '',
        filterOperator: '',
        filterValue: [],
        fieldType: 'input',
        filterOperators: [],
        filterOptions: [],
        searchType: 'criteria',
        filterFieldError: '',
        valueError: '',
        OperatorError: '',
        fromError: '',
        toError: '',
      },
    ],
    isFilterApplied: true,
  },
  alertDetails: {
    data: {},
    loading: false,
  },
  export: {
    loading: false,
    error: '',
  },
  comments: {
    data: [
      {
        alertId: 'SAN-CS-4572',
        commentId: 'C123',
        commentText: 'comment#',
        createdOnDate: '20-JAN-2024',
        createdById: 'John Doe',
      },
    ],
  },
  history: {
    data: [
      {
        id: '948af24f-2573-4a47-8042-9e5be3a7b883',
        description: 'Alert is Assigned to "SendManager1"',
        createdBy: 'SendManager1',
        createdDate: '2024-03-26T08:42:48.268Z',
      },
    ],
  },
  attachments: {
    data: [
      {
        id: '948af24f-2573-4a47-8042-9e5be3a7b883',
        alertAttachmentId: '948af24f-2573-4a47-8042-9e5be3a7b883',
        documentName: 'test-file.xlsx',
        documentType: 'Action_Plan',
        createdById: 'test name',
        createdDate: '2024-03-26T08:42:48.268Z',
      },
    ],
  },
}

// re-export everything
export * from '@testing-library/react'

// override render method
export {
  customRenderWithProvider,
  customRenderWithRouter,
  customRenderWithProviderRouter,
  render,
  mockStore,
  testStore,
}
