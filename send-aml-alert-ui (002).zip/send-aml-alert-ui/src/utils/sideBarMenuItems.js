export const menuItem = (titleValue, dataTestIdValue, urlValue, submenus) => {
  const submenu = {
    title: titleValue,
    dataTestId: dataTestIdValue,
    url: urlValue,
  }
  if (submenus?.length) {
    submenu['submenus'] = submenus
  }
  return submenu
}

export const alertDetailsSideBarMenus = [
  menuItem('Overview', 'overview-section', '#overview-section'),
  menuItem('Comments', 'comments-section', '#comments-section'),
  menuItem('Attachments', 'attachments-section', '#attachments-section'),
  menuItem('History', 'history-section', '#history-section'),
]
