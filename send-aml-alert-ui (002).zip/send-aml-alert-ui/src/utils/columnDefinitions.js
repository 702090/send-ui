import { Link } from 'react-router-dom'
import { LABEL_MAPPER } from '../constants/AppConstants'
import { formatTableDate } from './dateUtility'
import { changeStatusToBold, capitalizeText } from './utility'
import categories from '../components/Attachments/categories.json'
import moment from 'moment'

export const attachmentsColDef = [
  {
    grow: 1,
    itemKey: 'documentType',
    label: 'Category',
    sortable: true,
    onRender: (params) =>
      categories.find((i) => i.value === params.documentType)?.label,
  },
  {
    grow: 1,
    itemKey: 'createdById',
    label: 'Uploaded by',
    sortable: true,
    onRender: (params) => params.createdById,
  },
  {
    grow: 1,
    itemKey: 'createdDate',
    label: 'Upload date',
    onRender: (params) => {
      return formatTableDate(params.createdDate)
    },
    sortable: true,
  },
]

export const historyColDef = [
  {
    id: 'performedDate',
    itemKey: 'performedDate',
    onRender: (params) => formatTableDate(params.performedDate),
    label: 'Date and time',
  },
  {
    id: 'description',
    itemKey: 'description',
    label: 'Description',
    onRender: (params) => changeStatusToBold(params.description),
  },
  {
    id: 'createdBy',
    itemKey: 'createdBy',
    label: 'Performed by',
    onRender: (params) => params.createdBy,
  },
]
export const defaultAlertListColDef = [
  {
    itemKey: 'id',
    label: LABEL_MAPPER.alertId,
    sortable: true,
    disabled: true,
    onRender: (params) => cellRenderer(params, 'alert'),
    grow: 10,
  },
  {
    itemKey: 'alertStatus',
    label: LABEL_MAPPER.alertStatus,
    sortable: true,
    onRender: (params) => capitalizeText(params.alertStatus),
  },
  {
    itemKey: 'actionDescription',
    label: LABEL_MAPPER.actionDescription,
    sortable: true,
    onRender: (params) => params.actionDescription,
  },
  {
    itemKey: 'alertGenerationDate',
    label: LABEL_MAPPER.alertAge,
    sortable: true,
    onRender: (params) => moment(params.alertGenerationDate).fromNow(),
  },
  {
    itemKey: 'alertAge',
    label: LABEL_MAPPER.alertGenerationDate,
    sortable: true,
    onRender: (params) =>
      moment(params.alertGenerationDate).format('DD MMM YYYY, HH:MM A'),
  },
  {
    itemKey: 'rule',
    label: LABEL_MAPPER.rule,
    sortable: true,
    onRender: (params) => capitalizeText(params.rule),
  },
  {
    itemKey: 'transactionType',
    label: LABEL_MAPPER.transactionType,
    sortable: true,
    onRender: (params) => params.transactionType,
  },
  {
    itemKey: 'transactionTypeIdentifier',
    label: LABEL_MAPPER.transactionTypeIdentifier,
    sortable: true,
    onRender: (params) => params.transactionTypeIdentifier,
  },
  {
    itemKey: 'amountExceeded',
    label: LABEL_MAPPER.amountExceeded,
    sortable: true,
    onRender: (params) => params.amountExceeded,
  },
  {
    itemKey: 'thresholdPercentage',
    label: LABEL_MAPPER.thresholdPercentage,
    sortable: true,
    onRender: (params) => params.thresholdPercentage,
  },
  {
    itemKey: 'percentageExceeded',
    label: LABEL_MAPPER.percentageExceeded,
    sortable: true,
    onRender: (params) => params.percentageExceeded,
  },
  {
    itemKey: 'ruleVersion',
    label: LABEL_MAPPER.ruleVersion,
    sortable: true,
    onRender: (params) => params.ruleVersion,
    hidden: true,
  },
  {
    itemKey: 'thresholdAmount',
    label: LABEL_MAPPER.thresholdAmount,
    sortable: true,
    onRender: (params) => params.thresholdAmount,
    hidden: true,
  },
  {
    itemKey: 'xbOrDom',
    label: LABEL_MAPPER.XbOrDom,
    sortable: true,
    onRender: (params) => params.xbOrDom,
    hidden: true,
  },
  {
    itemKey: 'percentageAmountExceeded',
    label: LABEL_MAPPER.percentageAmountExceeded,
    sortable: true,
    onRender: (params) => params.percentageAmountExceeded,
    hidden: true,
  },
  {
    itemKey: 'network',
    label: LABEL_MAPPER.network,
    sortable: true,
    onRender: (params) => capitalizeText(params.network),
    hidden: true,
  },
  {
    itemKey: 'region',
    label: LABEL_MAPPER.region,
    sortable: true,
    onRender: (params) => capitalizeText(params.region),
    hidden: true,
  },
  {
    itemKey: 'oiRi',
    label: LABEL_MAPPER.oiRi,
    sortable: true,
    onRender: (params) => params.oiRi,
    hidden: true,
  },
  {
    itemKey: 'oiRiRegion',
    label: LABEL_MAPPER.oiRiRegion,
    sortable: true,
    onRender: (params) => capitalizeText(params.oiRiRegion),
    hidden: true,
  },
  {
    itemKey: 'oiRiCountry',
    label: LABEL_MAPPER.oiRiCountry,
    sortable: true,
    onRender: (params) => capitalizeText(params.oiRiCountry),
    hidden: true,
  },
  {
    itemKey: 'oiRiCid',
    label: LABEL_MAPPER.oiRiCid,
    sortable: true,
    onRender: (params) => params.oiRiCid,
    hidden: true,
  },
  {
    itemKey: 'alertType',
    label: LABEL_MAPPER.alertType,
    sortable: true,
    onRender: (params) => capitalizeText(params.alertType),
    hidden: true,
  },
]

export const cellRenderer = (params, type) => {
  return <Link to={`/${type}-details/${params.id}`}>{params.id}</Link>
}
