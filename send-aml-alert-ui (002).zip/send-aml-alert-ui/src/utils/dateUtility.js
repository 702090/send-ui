import moment from 'moment'
import { FILTER_OPERATOR } from '../constants/AppConstants'
import { PLEASE_SELECT_DATE } from '../constants/AppErrors'
import { compareAsc } from 'date-fns'

export const formatDate = (date, format = 'DD-MMM-YYYY') => {
  return moment(date).format(format)
}

export const formatAttachmentsDate = (rawTS) => {
  return moment(rawTS).format('DD MMM YYYY')
}

export const getCurrentTimeStamp = () => {
  return new Date().getTime().toString()
}

export const formatTableDate = (rawTS) => {
  return moment(rawTS).format('DD MMM YYYY, HH:MM A')
}

export const validateDateFilter = (filterData) => {
  let isError = false
  if (!filterData.from) {
    filterData.fromError = PLEASE_SELECT_DATE
    isError = true
  }
  if (filterData.filterOperator === FILTER_OPERATOR.BETWEEN) {
    if (!filterData.to) {
      filterData.toError = PLEASE_SELECT_DATE
      return true
    }
    const isFromDateExceedsToDate = compareAsc(
      new Date(filterData.from),
      new Date(filterData.to)
    )
    if (filterData.to && isFromDateExceedsToDate === 1) {
      filterData.invalidDateError = 'From date should be before To date'
      isError = true
    } else {
      filterData.invalidDateError = ''
    }
  }
  return isError
}
