import { isEmpty } from 'lodash'
import { setToastDetails } from '../store/reducers/ToastDetailsSlice'
import moment from 'moment'

export const getPrefix = () => {
  const environment = process.env.REACT_APP_ENVIRONMENT_NAME
  if (environment === 'dev') {
    return `/sendamlportal-dev-alerts-ui`
  } else if (environment === 'stage') {
    return `/sendamlportal-stage-alerts-ui`
  } else {
    return `/sendamlportal-alerts-ui`
  }
}

export const getFullUrl = (endpoint) => {
  switch (endpoint) {
    case findEndpoint(endpoint, '/cases/'):
      return `${process.env.REACT_APP_CASE_API_BASE_URL}${endpoint}`
    case findEndpoint(endpoint, '/alerts/'):
      return `${process.env.REACT_APP_ALERT_API_BASE_URL}${endpoint}`
    default:
      return `${process.env.REACT_APP_ALERT_API_BASE_URL}${endpoint}`
  }
}

export const findEndpoint = (endpoint, app) => {
  if (endpoint.includes(app)) {
    return endpoint
  }
}

export const capitalizeText = (text) => {
  if (text) {
    return text.replace(/\w+/g, function (w) {
      return w[0].toUpperCase() + w.slice(1).toLowerCase()
    })
  }
}

export const changeStatusToBold = (text) => {
  const textArray = text.split('"')
  if (textArray.length > 1) {
    return (
      <>
        <span>
          {textArray[0]}
          <b>
            {'"'}
            {textArray[1]}
            {'"'}
          </b>
          {textArray[2]}
          {textArray.length > 2 && !isEmpty(textArray[3]) ? (
            <b>
              {'"'}
              {textArray[3]}
              {'"'}
              {textArray[4]}
            </b>
          ) : null}
        </span>
      </>
    )
  } else {
    return text
  }
}

export const indexedWithId = (data, key) => {
  return data.map((d) => ({ ...d, id: d[key] }))
}

export const getIdFromURL = () => {
  const urlArray = window.location.href.split('/')
  return urlArray[urlArray.length - 1]
}

export const getSortedItems = ({ items, sortReversed, sortByColumn }) => {
  const sortedItems = !sortByColumn
    ? items
    : [...items].sort((prev, next) => {
        const prevItem = prev[sortByColumn]
        const nextItem = next[sortByColumn]
        const prevItemComparable = prevItem ? getComparableItem(prevItem) : ''
        const nextItemComparable = nextItem ? getComparableItem(nextItem) : ''

        if (prevItemComparable > nextItemComparable) {
          return !sortReversed ? 1 : -1
        } else if (nextItemComparable > prevItemComparable) {
          return !sortReversed ? -1 : 1
        }

        return 0
      })
  return sortedItems
}

export const getComparableItem = (value) => {
  if (typeof value === 'string') {
    return value.toLowerCase()
  }
  return value
}

export const toastSetter = ({ type, success, error, dispatch }) => {
  let payload = {}
  if (type.includes('fulfilled')) {
    payload = {
      type: 'success',
      message: success,
      duration: 4000,
      visible: true,
    }
  } else {
    payload = {
      type: 'error',
      message: error,
      duration: 4000,
      visible: true,
    }
  }
  dispatch(setToastDetails(payload))
}

export const downloadFile = (content, docName = '') => {
  const domElement = document.createElement('a')
  if (content instanceof Blob) {
    domElement.href = URL.createObjectURL(content)
  }
  let fileName
  if (!docName) {
    const dateFormat = moment().format('yyyy-MM-DD-HH-mm')
    fileName = `Alerts_${dateFormat}.xls`
  } else {
    fileName = docName
  }
  domElement.download = fileName
  document.body.appendChild(domElement)
  domElement.click()
  domElement.remove()
}
