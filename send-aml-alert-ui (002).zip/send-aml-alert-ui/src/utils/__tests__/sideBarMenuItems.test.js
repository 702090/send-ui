import React from 'react'
import { render } from '@testing-library/react'
import { menuItem, alertDetailsSideBarMenus } from '../sideBarMenuItems' // Replace 'yourFile' with the path to your file

describe('menuItem function', () => {
  it('should create a menu item without submenus', () => {
    const menuItemData = menuItem('Test Title', 'test-data', '#test-url')
    expect(menuItemData).toEqual({
      title: 'Test Title',
      dataTestId: 'test-data',
      url: '#test-url',
    })
  })

  it('should create a menu item with submenus', () => {
    const submenus = [
      { title: 'Submenu 1', dataTestId: 'submenu-1', url: '#submenu-1' },
      { title: 'Submenu 2', dataTestId: 'submenu-2', url: '#submenu-2' },
    ]
    const menuItemData = menuItem(
      'Test Title',
      'test-data',
      '#test-url',
      submenus
    )
    expect(menuItemData).toEqual({
      title: 'Test Title',
      dataTestId: 'test-data',
      url: '#test-url',
      submenus: [
        { title: 'Submenu 1', dataTestId: 'submenu-1', url: '#submenu-1' },
        { title: 'Submenu 2', dataTestId: 'submenu-2', url: '#submenu-2' },
      ],
    })
  })
})

describe('alertDetailsSideBarMenus array', () => {
  it('should contain correct menu items', () => {
    const { getByTestId } = render(
      <>
        {alertDetailsSideBarMenus.map((menu, index) => (
          <div key={index} data-testid={menu.dataTestId}>
            {menu.title}
          </div>
        ))}
      </>
    )

    expect(getByTestId('overview-section')).toHaveTextContent('Overview')
    expect(getByTestId('comments-section')).toHaveTextContent('Comments')
    expect(getByTestId('attachments-section')).toHaveTextContent('Attachments')
    expect(getByTestId('history-section')).toHaveTextContent('History')
  })

  it('should contain correct number of menu items', () => {
    expect(alertDetailsSideBarMenus.length).toBe(4)
  })
})
