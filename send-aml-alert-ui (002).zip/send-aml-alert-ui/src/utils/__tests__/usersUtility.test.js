const {
  sortUsersByFullName,
  concatFullName,
  nullCheck,
  getUserId,
} = require('../usersUtility')

describe('User functions', () => {
  it('sorts users by full name correctly', () => {
    const users = [
      { firstname: 'John', lastname: 'Doe', eid: 1 },
      { firstname: 'Alice', lastname: 'Smith', eid: 2 },
    ]
    sortUsersByFullName(users)
    expect(users[0].firstname).toEqual('Alice')
    expect(users[1].firstname).toEqual('John')
  })
  it('sorts users by full name correctly', () => {
    const users = [
      { firstname: 'Alice', lastname: 'Smith', eid: 1 },
      { firstname: 'John', lastname: 'Doe', eid: 2 },
    ]
    sortUsersByFullName(users)
    expect(users[0].firstname).toEqual('Alice')
    expect(users[1].firstname).toEqual('John')
  })
  it('sorts users by full name correctly', () => {
    const users = [
      { firstname: 'Alice', lastname: 'Smith', eid: 1 },
      { firstname: 'Alice', lastname: 'Smith', eid: 2 },
    ]
    sortUsersByFullName(users)
    expect(users[0].firstname).toEqual('Alice')
    expect(users[1].firstname).toEqual('Alice')
  })
  it('concatenates full names correctly', () => {
    const userDetails = { firstname: 'John', lastname: 'Doe' }
    const fullName = concatFullName(userDetails)
    expect(fullName).toEqual('John Doe')
  })
  it('gets no user if list is empty', () => {
    const users = []
    const result = getUserId(users)
    expect(result).toBe()
  })
  it('gets user id correctly', () => {
    const users = [
      { firstname: 'John', lastname: 'Doe', eid: 1 },
      { firstname: 'Alice', lastname: 'Smith', eid: 2 },
    ]
    const value = 'John Doe'
    const result = getUserId(users, value)
    expect(result).toEqual(1)
  })
  describe('nullCheck function', () => {
    test.each([
      [null, ''],
      [undefined, ''],
      ['John', 'John'],
      ['   John   ', 'John'],
    ])('handles null values correctly', (input, expected) => {
      const result = nullCheck(input)
      expect(result).toBe(expected)
    })
  })
})
