import { render, screen } from '@testing-library/react'
import { historyColDef, attachmentsColDef } from '../columnDefinitions'
import { formatTableDate } from '../dateUtility'

describe('History Table Column Definitions', () => {
  test('Description column should render correctly', () => {
    const params = { description: 'Test Description' }
    render(historyColDef[1].onRender(params))
    const descriptionElement = screen.getByText('Test Description')
    expect(descriptionElement).toBeInTheDocument()
  })

  test('onRender in historyColDef calls formatTableDate with correct parameters', () => {
    const performedDate = new Date('2022-04-15T12:00:00')
    const formattedDate = formatTableDate(performedDate)
    const onRender = historyColDef.find(
      (col) => col.itemKey === 'performedDate'
    ).onRender
    const result = onRender({ performedDate })

    expect(result).toEqual(formattedDate)
  })
})

describe('Attachments Column Definitions', () => {
  test('onRender in attachmentsColDef calls formatTableDate with correct parameters', () => {
    const createdDate = new Date('2022-04-15T12:00:00')
    const formattedDate = formatTableDate(createdDate)
    const onRender = attachmentsColDef.find(
      (col) => col.itemKey === 'createdDate'
    ).onRender
    const result = onRender({ createdDate })

    expect(result).toEqual(formattedDate)
  })
})
