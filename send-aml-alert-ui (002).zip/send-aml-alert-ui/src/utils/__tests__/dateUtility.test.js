import moment from 'moment'
import {
  formatDate,
  formatAttachmentsDate,
  getCurrentTimeStamp,
  formatTableDate,
  validateDateFilter,
} from '../dateUtility'

describe('Test all date utility functions', () => {
  it('formats date correctly with default format', () => {
    const date = new Date('2024-04-05')
    expect(formatDate(date)).toEqual(moment(date).format('DD-MMM-YYYY'))
  })

  it('formats date correctly with custom format', () => {
    const date = new Date('2024-04-05')
    expect(formatDate(date, 'YYYY/MM/DD')).toEqual(
      moment(date).format('YYYY/MM/DD')
    )
  })

  it('formats attachments date correctly', () => {
    const rawTS = '2024-04-05T12:00:00Z'
    expect(formatAttachmentsDate(rawTS)).toEqual(
      moment(rawTS).format('DD MMM YYYY')
    )
  })

  it('returns current timestamp as string', () => {
    const currentTimeStamp = getCurrentTimeStamp()
    expect(typeof currentTimeStamp).toBe('string')
    expect(parseInt(currentTimeStamp, 10)).toBeGreaterThan(0)
  })

  it('formats table date correctly', () => {
    const rawTS = '2024-04-05T12:00:00Z'
    expect(formatTableDate(rawTS)).toEqual(
      moment(rawTS).format('DD MMM YYYY, HH:MM A')
    )
  })
  it('validateDateFilter works in table date correctly', () => {
    const filterData = {
      filterOperator: 'BETWEEN',
      from: '2024-04-05T12:00:00Z',
      to: '2024-04-06T12:00:00Z',
    }
    expect(validateDateFilter(filterData)).toBeFalsy()
  })
  it('validateDateFilter works in table date correctly', () => {
    const filterData = {
      filterOperator: 'BETWEEN',
      from: '2024-04-05T12:00:00Z',
      to: '2024-04-03T12:00:00Z',
    }
    expect(validateDateFilter(filterData)).toBeTruthy()
  })
})
