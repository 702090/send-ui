import { render } from '@testing-library/react'
import {
  getPrefix,
  getFullUrl,
  findEndpoint,
  changeStatusToBold,
  capitalizeText,
  getSortedItems,
  toastSetter,
  downloadFile,
} from '../utility'
import response from '../../__mocks__/alertList.json'

describe('getPrefix function test cases', () => {
  test('Returns correct prefix for REACT_APP_ENVIRONMENT_NAME "stage"', () => {
    process.env.REACT_APP_ENVIRONMENT_NAME = 'stage'
    const prefix = getPrefix()
    expect(prefix).toEqual('/sendamlportal-stage-alerts-ui')
  })

  test('Returns correct prefix for REACT_APP_ENVIRONMENT_NAME "dev"', () => {
    process.env.REACT_APP_ENVIRONMENT_NAME = 'dev'
    const prefix = getPrefix()
    expect(prefix).toEqual('/sendamlportal-dev-alerts-ui')
  })

  test('Returns default prefix for other REACT_APP_ENVIRONMENT_NAME values', () => {
    process.env.REACT_APP_ENVIRONMENT_NAME = 'prod'
    const prefix = getPrefix()
    expect(prefix).toEqual('/sendamlportal-alerts-ui')
  })
})

describe('getFullUrl function test cases', () => {
  test('Returns correct URL for endpoint starting with "/cases/"', () => {
    process.env.REACT_APP_CASE_API_BASE_URL = 'https://case-endpoint.com'
    expect(getFullUrl('/cases/list')).toEqual(
      'https://case-endpoint.com/cases/list'
    )
  })

  test('Returns correct URL for endpoint starting with "/alerts/"', () => {
    process.env.REACT_APP_ALERT_API_BASE_URL = 'https://alert-endpoint.com'
    expect(getFullUrl('/alerts/details')).toEqual(
      'https://alert-endpoint.com/alerts/details'
    )
  })

  test('Returns default URL for other endpoints', () => {
    process.env.REACT_APP_ALERT_API_BASE_URL = 'https://default-endpoint.com'
    expect(getFullUrl('/other/endpoint')).toEqual(
      'https://default-endpoint.com/other/endpoint'
    )
  })
})

describe('findEndpoint function test cases', () => {
  test('Returns endpoint if it includes the specified app', () => {
    const endpoint = '/cases/list'
    const app = '/cases/'
    expect(findEndpoint(endpoint, app)).toEqual(endpoint)
  })

  test('Returns undefined if endpoint does not include the specified app', () => {
    const endpoint = '/other/endpoint'
    const app = '/cases/'
    expect(findEndpoint(endpoint, app)).toEqual(undefined)
  })
})

describe('changeStatusToBold function', () => {
  test('Returns text unchanged if it does not contain double quotes', () => {
    const text = 'This is a test message'
    const { container } = render(<div>{changeStatusToBold(text)}</div>)
    expect(container.firstChild.textContent).toEqual(text)
  })

  test('Returns text unchanged if it  contain double quotes', () => {
    const text = 'This is a test "message"'
    const { container } = render(<div>{changeStatusToBold(text)}</div>)
    expect(container.firstChild.textContent).toEqual(text)
  })

  test('Returns text unchanged if it  contain double quotes', () => {
    const text = 'This is a test "message" is "here"'
    const { container } = render(<div>{changeStatusToBold(text)}</div>)
    expect(container.firstChild.textContent).toEqual(
      'This is a test "message" is "here"'
    )
  })

  test('Handles empty input correctly', () => {
    const text = ''
    const { container } = render(<div>{changeStatusToBold(text)}</div>)
    expect(container.firstChild.textContent).toEqual('')
  })

  test('capitalizeText empty input correctly', () => {
    expect(capitalizeText()).toBe()
  })
})

describe('getSortedItems function test cases', () => {
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: true,
        sortByColumn: 'alertType',
      })
    ).toHaveLength(2)
  })
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: true,
        sortByColumn: 'thresholdAmount',
      })
    ).toHaveLength(2)
  })
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: true,
        sortByColumn: '',
      })
    ).toHaveLength(2)
  })
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: true,
        sortByColumn: 'amountExceeded',
      })
    ).toHaveLength(2)
  })
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: false,
        sortByColumn: 'thresholdAmount',
      })
    ).toHaveLength(2)
  })
  test('getSortedItems input correctly', () => {
    expect(
      getSortedItems({
        items: response.items,
        sortReversed: false,
        sortByColumn: 'amountExceeded',
      })
    ).toHaveLength(2)
  })
  test('toastSetter returns when api fails', () => {
    expect(
      toastSetter({
        type: 'rejected',
        success: false,
        error: 'Failed response',
        dispatch: jest.fn(),
      })
    ).toBe()
  })
})
describe('downloadFile testcases: BLOB', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    jest.spyOn(document, 'createElement').mockImplementation(() => ({
      click: jest.fn(),
      remove: jest.fn(),
    }))
    jest
      .spyOn(document['body'], 'appendChild')
      .mockImplementationOnce(() => ({}))
    window.URL.createObjectURL = () => {}
    downloadFile(
      'data:text/csv;charset=utf-8,ID,Name%0A1,abc%0A2,def%0A',
      'cases.xlxs'
    )
  })
  afterAll(() => {
    jest.clearAllMocks()
  })
  it('create element should only call one time', () => {
    expect(document.createElement).toHaveBeenCalledTimes(1)
  })
  it('Create element should call with an anchor tag', () => {
    expect(document.createElement).toHaveBeenCalledWith('a')
  })
})

describe('downloadFile testcases: BLOB FILE', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    jest.spyOn(document, 'createElement').mockImplementation(() => ({
      click: jest.fn(),
      remove: jest.fn(),
    }))
    jest
      .spyOn(document['body'], 'appendChild')
      .mockImplementationOnce(() => ({}))
    window.URL.createObjectURL = () => {}
    const temp = new Blob()
    downloadFile(temp)
  })
  afterAll(() => {
    jest.clearAllMocks()
  })
  it('create element should only call one time', () => {
    expect(document.createElement).toHaveBeenCalledTimes(1)
  })
  it('Create element should call with an anchor tag', () => {
    expect(document.createElement).toHaveBeenCalledWith('a')
  })
})
