const LabelGenerator = ({ value, isRequired }) => {
  return (
    <div className="plain-label">
      {value}
      {isRequired && <span className="mandatory-asterisk">*</span>}
    </div>
  )
}

export default LabelGenerator
