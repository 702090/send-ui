import { render } from '../../../utils/testUtils'
import LabelGenerator from '../'

describe('LabelGenerator component unit test coverage', () => {
  it('should render LabelGenerator component', async () => {
    render(<LabelGenerator value="Test label" isRequired={true} />, {})
  })
})
