import { render, screen, fireEvent } from '../../../utils/testUtils'
import SearchBar from '../'

describe('SearchBar component test cases', () => {
  test('Verify SearchBar is getting rendered correctly', () => {
    render(
      <SearchBar placeholderText={'Search by alert id'} onSearch={jest.fn()} />,
      {}
    )
    expect(screen.getByTestId('search-component-holder')).toBeInTheDocument()
  })
  test('Verify SearchBar with incomplete entries', async () => {
    render(
      <SearchBar placeholderText={'Search by alert id'} onSearch={jest.fn()} />,
      {}
    )
    const searchInput = screen.getByPlaceholderText('Search by alert id')
    await fireEvent.change(searchInput, { target: { value: 'TEST-171-705' } })
    await fireEvent.keyDown(searchInput, { key: 'Enter', charCode: 13 })
  })
  test('Verify SearchBar with correct entries', async () => {
    render(
      <SearchBar placeholderText={'Search by alert id'} onSearch={jest.fn()} />,
      {}
    )
    const searchInput = screen.getByPlaceholderText('Search by alert id')
    await fireEvent.change(searchInput, { target: { value: 'TE' } })
  })
  test('Verify SearchBar with no entries', async () => {
    render(
      <SearchBar placeholderText={'Search by alert id'} onSearch={jest.fn()} />,
      {}
    )
    const searchInput = screen.getByPlaceholderText('Search by alert id')
    await fireEvent.change(searchInput, { target: { value: 'T' } })
    await fireEvent.change(searchInput, { target: { value: '' } })
  })
})
