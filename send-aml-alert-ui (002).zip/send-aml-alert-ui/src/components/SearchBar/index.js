import SearchInput from '@connect/search-input'
import { useState, useEffect } from 'react'
import Grid, { GridColumn } from '@connect/grid'

const SearchBar = ({ placeholderText, onSearch }) => {
  const [searchInputValue, setSearchInputValue] = useState('')
  const [error, setError] = useState('')

  const handleSearch = (event) => {
    if (event.key === 'Enter') {
      onSearch(searchInputValue)
    }
  }
  useEffect(() => {
    document
      .getElementById('alert-search-input')
      ?.addEventListener('keydown', handleSearch)
    return () => {
      document
        .getElementById('alert-search-input')
        ?.removeEventListener('keydown', handleSearch)
    }
  }, [handleSearch])

  const handleChange = (value) => {
    setSearchInputValue(value)
    if (!value) {
      setError('')
      onSearch(value)
    } else if (value.length < 3) {
      setError('Search box must contain at least three digits')
    } else {
      setError('')
    }
  }

  return (
    <div
      id="alert-search-input"
      className="search-component-holder"
      data-testid="search-component-holder"
    >
      <Grid>
        <GridColumn size={4.02} fillGapStart={true}>
          <SearchInput
            placeholder={placeholderText}
            onChange={handleChange}
            value={searchInputValue}
          />
          <span
            style={{
              color: '#d7373c',
            }}
          >
            {error}
          </span>
        </GridColumn>
      </Grid>
    </div>
  )
}

export default SearchBar
