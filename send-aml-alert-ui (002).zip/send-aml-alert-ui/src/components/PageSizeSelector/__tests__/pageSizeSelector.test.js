import { render, screen, fireEvent } from '../../../utils/testUtils'
import PageSizeSelector from '../'

describe('PageSizeSelector component test cases', () => {
  test('Verify PageSizeSelector is getting rendered correctly', async () => {
    render(
      <PageSizeSelector
        pageLength={20}
        setPageSize={jest.fn()}
        defaultValue={5}
      />,
      {}
    )
    expect(screen.getByTestId('select-page-size')).toBeInTheDocument()
    await fireEvent.change(screen.getByTestId('select-page-size'), {
      target: { value: '10' },
    })
  })
})
