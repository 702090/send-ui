import React, { useEffect, useState } from 'react'

const PageSizeSelector = ({ pageLength, setPageSize, defaultValue }) => {
  const [value, setValue] = useState(pageLength)
  useEffect(() => {
    setValue(pageLength)
  }, [pageLength])

  return (
    <div className="page-size-selector">
      <select
        data-testid="select-page-size"
        onChange={(event) => {
          setPageSize(event?.target?.value)
          setValue(event?.target?.value)
        }}
        defaultValue={defaultValue}
        value={value}
        aria-label="Select page length for pagination"
      >
        <option value="10">10</option>
        <option value="25">25 </option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
    </div>
  )
}

export default PageSizeSelector
