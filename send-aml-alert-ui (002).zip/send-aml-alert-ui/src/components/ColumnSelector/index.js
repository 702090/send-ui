import ActionBar, { Action } from '@connect/action-bar'
import Scrollbar from '@connect/scrollbar'
import Checkbox, { CheckboxGroup } from '@connect/checkbox'
import { useSelector, useDispatch } from 'react-redux'
import { useState } from 'react'
import {
  toggleAlertCheckbox,
  resetColumns,
  setCurrentAction,
} from '../../store/reducers/AlertListSlice'
import { Link } from 'react-router-dom'

const ColumnSelector = () => {
  const dispatch = useDispatch()
  const [dropVisible, setDropVisible] = useState(false)
  const columnDefs = useSelector((state) => state.alertList.columns)
  const { currentAction } = useSelector((state) => state.alertList)
  const handleCheckboxClick = (itemKey) => {
    dispatch(toggleAlertCheckbox(itemKey))
  }
  return (
    <>
      <div className="action-item-column">
        <ActionBar>
          <div>
            <Action
              label="Columns"
              onClick={() => {
                setDropVisible(!dropVisible)
                dispatch(setCurrentAction('columns'))
              }}
            >
              <></>
            </Action>
          </div>
        </ActionBar>
        {dropVisible && currentAction === 'columns' && (
          <div className="checkbox-group" data-testid="checkbox-group">
            <Link
              to={'#'}
              onClick={() => {
                dispatch(resetColumns())
                setDropVisible(false)
              }}
            >
              Reset
            </Link>
            <Scrollbar maxHeight={250}>
              <CheckboxGroup>
                {columnDefs.map((columnDef) => (
                  <div key={columnDef.itemKey}>
                    <Checkbox
                      key={columnDef.itemKey}
                      name={columnDef.itemKey}
                      label={columnDef.label}
                      checked={!columnDef.hidden}
                      disabled={columnDef.disabled}
                      onChange={() => handleCheckboxClick(columnDef.itemKey)}
                    ></Checkbox>
                  </div>
                ))}
              </CheckboxGroup>
            </Scrollbar>
          </div>
        )}
      </div>
    </>
  )
}
export default ColumnSelector
