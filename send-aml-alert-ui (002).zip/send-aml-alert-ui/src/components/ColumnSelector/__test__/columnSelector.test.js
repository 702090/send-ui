import {
  mockStore,
  render,
  screen,
  testStore,
  fireEvent,
} from '../../../utils/testUtils'
import ColumnSelector from '../'

describe('ColumnSelector component unit test coverage', () => {
  const alertList = { ...testStore.alertList }
  const store = mockStore({
    ...testStore,
    alertList: { ...alertList, currentAction: 'columns' },
  })
  it('should render ColumnSelector component', async () => {
    render(<ColumnSelector />, { store })
    const column = screen.getByText('Columns')
    await fireEvent.click(column)
    await fireEvent.click(screen.getByText('Alert Status'))
    await fireEvent.click(screen.getByText('Reset'))
  })
})
