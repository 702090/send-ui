import {
  mockStore,
  render,
  screen,
  testStore,
  fireEvent,
} from '../../../utils/testUtils'
import userEvent from '@testing-library/user-event'
import Attachments from '../'

describe('Attachments component unit test coverage', () => {
  const store = mockStore(testStore)
  it('should render Attachments component with no id', async () => {
    render(<Attachments />, { store })
  })
  it('should render Attachments component', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    const attachments = screen.getByText('ATTACHMENTS')
    await fireEvent.click(screen.getByText('Document name'))
    expect(attachments).toBeInTheDocument()
    const inputFile = container.querySelector('[type="file"]')
    expect(inputFile).toBeDisabled()
  })
  it('should render Attachments component with upload enabled', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    const category = screen.getByRole('combobox', { name: 'Select a category' })
    await fireEvent.click(category)
    await fireEvent.click(screen.getByText(/action plan/i))
    const inputFile = container.querySelector('[type="file"]')
    expect(inputFile).not.toBeDisabled()
    const file = new File(['hello'], 'hello.png', { type: 'image/png' })
    await userEvent.upload(inputFile, file)
  })
  it('should render Attachments component with upload enabled and all selected cancel', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    const selectAll = container.querySelector('[aria-label="Select all"]')
    await fireEvent.click(selectAll)
    const deleteButton = screen.getByRole('button', { name: 'Delete' })
    await fireEvent.click(deleteButton)
    const modalCancelButton = screen.getByRole('button', { name: 'No' })
    await fireEvent.click(modalCancelButton)
  })
  it('should render Attachments component with upload enabled and all selected close', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    const selectAll = container.querySelector('[aria-label="Select all"]')
    await fireEvent.click(selectAll)
    const deleteButton = screen.getByRole('button', { name: 'Delete' })
    await fireEvent.click(deleteButton)
    await fireEvent.click(screen.getByRole('button', { name: /Close Modal/i }))
  })
  it('should render Attachments component with upload enabled and all selected close', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    const selectAll = container.querySelector('[aria-label="Select all"]')
    await fireEvent.click(selectAll)
    const deleteButton = screen.getByRole('button', { name: 'Delete' })
    await fireEvent.click(deleteButton)
    await fireEvent.click(screen.getByRole('button', { name: /Yes/i }))
  })
  it('should render Attachments component edit modal and close', async () => {
    render(<Attachments alertId={'12345'} />, { store })
    await fireEvent.click(screen.getByText('test-file.xlsx'))
    await fireEvent.click(screen.getByText('Edit'))
    await fireEvent.click(screen.getByRole('button', { name: /Close Modal/i }))
  })
  it('should render Attachments component edit modal and update', async () => {
    render(<Attachments alertId={'12345'} />, { store })
    await fireEvent.click(screen.getByText('test-file.xlsx'))
    await fireEvent.click(screen.getByText('Edit'))
    await fireEvent.click(screen.getByRole('button', { name: /Update/i }))
  })
  it('should render Attachments component edit modal and cancel', async () => {
    render(<Attachments alertId={'12345'} />, { store })
    await fireEvent.click(screen.getByText('test-file.xlsx'))
    await fireEvent.click(screen.getByText('Edit'))
    await fireEvent.click(screen.getByRole('button', { name: /Cancel/i }))
  })
  it('should render Attachments component', async () => {
    const { container } = render(<Attachments alertId={'12345'} />, { store })
    await fireEvent.click(screen.getByText('Document name'))
    const inputFile = container.querySelector('[type="file"]')
    expect(inputFile).toBeDisabled()
  })
})
describe('Attachments component unit test coverage', () => {
  const store = mockStore({ ...testStore, attachments: { data: [] } })
  it('should render Attachments component if no attachments found', async () => {
    render(<Attachments alertId={'12345'} />, { store })
    const attachments = screen.getByText('No attachments found')
    expect(attachments).toBeInTheDocument()
  })
})
