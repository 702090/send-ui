import { Eyebrow, TypeSize } from '@connect/typography'
import {
  SECTIONS,
  LABEL_MAPPER,
  PLACEHOLDERS,
  BUTTONS,
} from '../../constants/AppConstants'
import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import Grid, { GridColumn } from '@connect/grid'
import FileUpload, { FileTypes, FileUploadVariant } from '@connect/file-upload'
import LabelGenerator from '../LabelGenerator'
import Selector, { SelectorVariant } from '@connect/selector'
import categories from './categories.json'
import { attachmentsColDef } from '../../utils/columnDefinitions'
import DataTable from '@connect/data-table'
import { getSortedItems, indexedWithId } from '../../utils/utility'
import SectionLoader from '../SectionLoader'
import Button from '@connect/button'
import {
  getAttachments,
  addNewAttachment,
  downloadAttachments,
} from '../../store/reducers/AttachmentsSlice'
import NoRecordsHolder from '../../components/NoRecordsHolder'
import DeleteAttachmentsModal from './DeleteAttachmentsModal'
import EditAttachmentModal from './EditAttachmentModal'

const Attachments = ({ alertId }) => {
  const dispatch = useDispatch()
  const [columns, setColumns] = useState(attachmentsColDef)
  const { data, loading } = useSelector((state) => state.attachments)
  const [category, setCategory] = useState(null)
  const [deleteConfirmModal, setDeleteConfirmModal] = useState(false)
  const [updateModalVisible, setUpdateModalVisible] = useState(false)
  const [attachmentIdToEdit, setAttachmentIdToEdit] = useState(null)
  const [editableCategory, setEditableCategory] = useState(null)
  const initializeColumns = () => {
    const attachmentsColumn = [
      {
        grow: 2,
        itemKey: 'documentName',
        label: 'Document name',
        sortable: true,
        onRender: (params) => {
          return (
            <b
              style={{
                color: '#cf4500',
                fontWeight: '600px',
                cursor: 'pointer',
              }}
              onClick={() =>
                dispatch(downloadAttachments({ alertId, id: params.id }))
              }
            >
              {params.documentName}
            </b>
          )
        },
      },
      ...columns,
      {
        itemKey: 'action',
        label: 'Action',
        onRender: (params) => {
          return (
            <Button
              style={{
                textDecoration: 'none',
                fontSize: '0.95em',
              }}
              inline
              variant="ghost"
              onClick={() => {
                setAttachmentIdToEdit(params.id)
                setEditableCategory(params.documentType)
                setUpdateModalVisible(true)
              }}
            >
              Edit
            </Button>
          )
        },
      },
    ]
    setColumns(attachmentsColumn)
  }
  useEffect(() => {
    initializeColumns()
  }, [])
  useEffect(() => {
    const getAllAttachments = async () => {
      if (alertId) {
        await dispatch(getAttachments(alertId))
      }
    }
    getAllAttachments()
  }, [alertId])

  useEffect(() => {
    if (data?.length) {
      setState({ ...state, items: indexedWithId(data, 'alertAttachmentId') })
    }
  }, [data])
  const [state, setState] = useState({
    items: [],
    sortReversed: false,
    sortByColumn: null,
    selections: [],
    selectedAll: false,
  })
  useEffect(() => {
    setTimeout(() => {
      if (!state.selectedAll) {
        setState({
          ...state,
          selections: [],
        })
      }
    }, 10)
  }, [state.selectedAll])
  const handleChange = async (
    sortByColumn,
    sortReversed,
    _page,
    selections,
    selectedAll
  ) => {
    const items = getSortedItems({
      items: state.items,
      sortReversed,
      sortByColumn,
    })
    return setState({
      items,
      sortByColumn,
      sortReversed,
      selectedAll,
      selections,
    })
  }
  const onHandleFileUpload = async (files) => {
    const formData = new FormData()
    await formData.append('files', files[0])
    await dispatch(addNewAttachment({ alertId, formData, category }))
    await dispatch(getAttachments(alertId))
    setCategory(null)
  }
  const openDeleteFileModal = () => {
    setDeleteConfirmModal(true)
  }
  return (
    <div className="section-holder" id="attachments-section">
      {loading && <SectionLoader isVisible={loading} />}
      <Eyebrow size={TypeSize.Medium}>{SECTIONS.ATTACHMENTS}</Eyebrow>
      <p>
        Select a category before uploading a file. you will be able to edit the
        category once the attachment(s) is uploaded
      </p>
      <Grid responsive={true}>
        <GridColumn size={5} mt={3}>
          <LabelGenerator isRequired={false} value={LABEL_MAPPER.category} />
          <Selector
            ariaLabel={'add-attachment-selector'}
            name={'add-attachment-selector'}
            placeholder={PLACEHOLDERS.SELECT_A_CATEGORY}
            pt={1}
            pb={0.5}
            options={categories}
            variant={SelectorVariant.Primary}
            clearable={false}
            onChange={(val) => setCategory(val)}
            value={category}
          />
        </GridColumn>
        <GridColumn size={6} mt={3}>
          <FileUpload
            placeholder="file-upload"
            accept={[
              FileTypes.DOC,
              FileTypes.DOCX,
              FileTypes.XLS,
              FileTypes.XLSX,
              FileTypes.PPT,
              FileTypes.PPTX,
              FileTypes.JPG,
              FileTypes.PNG,
              FileTypes.TXT,
              FileTypes.ZIPExtension,
              FileTypes.PDF,
              FileTypes.CSV,
            ]}
            files={[]}
            maxItems={5}
            maxSize={5120}
            onChange={onHandleFileUpload}
            disabled={!category}
            variant={FileUploadVariant.Dropzone}
          />
        </GridColumn>
      </Grid>
      <div className="fileName">
        {state.selections.length > 0 && (
          <Button mb={4} onClick={() => openDeleteFileModal()}>
            {BUTTONS.DELETE}
          </Button>
        )}
        {deleteConfirmModal && (
          <DeleteAttachmentsModal
            visible={deleteConfirmModal}
            setVisible={setDeleteConfirmModal}
            selections={state.selections}
            alertId={alertId}
          />
        )}
        {updateModalVisible && (
          <EditAttachmentModal
            visible={updateModalVisible}
            setVisible={setUpdateModalVisible}
            alertId={alertId}
            attachmentIdToEdit={attachmentIdToEdit}
            setAttachmentIdToEdit={setAttachmentIdToEdit}
            editableCategory={editableCategory}
            setEditableCategory={setEditableCategory}
          />
        )}
        {data?.length ? (
          <div data-testid="list-table-component" className="list-table">
            <div className="attachments-table list-table-data">
              <DataTable
                id="attachments-grid"
                columns={columns}
                items={state.items}
                onChange={handleChange}
                selectable={true}
                selectedAll={state.selectedAll}
                selections={state.selections}
                resetSelectionOnHeaderClick={true}
                sortByColumn={state.sortByColumn}
                sortReversed={state.sortReversed}
              />
            </div>
          </div>
        ) : (
          <NoRecordsHolder section="attachments" />
        )}
      </div>
    </div>
  )
}
export default Attachments
