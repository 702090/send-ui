import Modal from '@connect/modal'
import { Paragraph } from '@connect/typography'
import { useDispatch } from 'react-redux'
import {
  deleteAttachments,
  getAttachments,
} from '../../store/reducers/AttachmentsSlice'

const DeleteAttachmentsModal = ({
  visible,
  setVisible,
  selections,
  alertId,
}) => {
  const dispatch = useDispatch()
  const deleteSelectedRecords = async () => {
    const ids = selections.join()
    setVisible(false)
    await dispatch(deleteAttachments({ alertId, ids }))
    await dispatch(getAttachments(alertId))
  }
  return (
    <Modal
      blocking={true}
      padded={true}
      columns={5}
      buttonPrimary={{
        label: 'Yes',
        onClick: () => deleteSelectedRecords(),
      }}
      buttonSecondary={{
        label: 'No',
        onClick: () => setVisible(false),
      }}
      onDismiss={() => setVisible(false)}
      visible={visible}
      duration={5}
      title="Delete Attachment(s)"
    >
      <Paragraph pad={[2, 0, 0, 0]}>
        Are you sure you want to delete the selected attachment(s)?
      </Paragraph>
    </Modal>
  )
}

export default DeleteAttachmentsModal
