import Modal from '@connect/modal'
import { useDispatch } from 'react-redux'
import {
  getAttachments,
  editAttachment,
} from '../../store/reducers/AttachmentsSlice'
import categories from './categories.json'
//import Grid, { GridColumn } from '@connect/grid'
import Selector, { SelectorVariant } from '@connect/selector'

const EditAttachmentModal = ({
  visible,
  setVisible,
  alertId,
  editableCategory,
  setEditableCategory,
  attachmentIdToEdit,
  setAttachmentIdToEdit,
}) => {
  const dispatch = useDispatch()
  const updateSelectedRecord = async () => {
    setVisible(false)
    await dispatch(
      editAttachment({
        alertId,
        attachmentId: attachmentIdToEdit,
        category: editableCategory,
      })
    )
    setAttachmentIdToEdit(null)
    await dispatch(getAttachments(alertId))
  }
  return (
    <Modal
      blocking={true}
      padded={true}
      columns={5}
      buttonPrimary={{
        label: 'Update',
        onClick: () => updateSelectedRecord(),
      }}
      buttonSecondary={{
        label: 'Cancel',
        onClick: () => setVisible(false),
      }}
      onDismiss={() => setVisible(false)}
      visible={visible}
      title="Update Attachment"
    >
      <div style={{ minHeight: '240px' }}>
        <Selector
          ariaLabel={'edit-attachment-selector'}
          name={'edit-attachment-selector'}
          pt={1}
          pb={0.5}
          options={categories}
          variant={SelectorVariant.Primary}
          clearable={false}
          onChange={(val) => setEditableCategory(val)}
          value={editableCategory}
        />
      </div>
    </Modal>
  )
}

export default EditAttachmentModal
