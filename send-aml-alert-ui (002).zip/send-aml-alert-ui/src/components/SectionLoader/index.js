import Spinner from '@connect/spinner'

const SectionLoader = ({ isVisible }) => {
  return (
    <div className="spinner-holder-small" data-testid="spinner-holder-section">
      <Spinner visible={isVisible} />
    </div>
  )
}

export default SectionLoader
