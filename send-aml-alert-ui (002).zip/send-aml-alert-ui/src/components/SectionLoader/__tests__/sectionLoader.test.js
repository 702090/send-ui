import { render, screen } from '../../../utils/testUtils'
import SectionLoader from '../'

describe('Screen Loader component test cases', () => {
  test('Verify ScreenLoader is getting rendered correctly', async () => {
    render(<SectionLoader />, {})
    const component = screen.getByTestId('spinner-holder-section')
    expect(component).toBeInTheDocument()
  })
})
