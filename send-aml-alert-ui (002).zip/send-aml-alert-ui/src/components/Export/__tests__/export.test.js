import {
  mockStore,
  render,
  screen,
  testStore,
  fireEvent,
} from '../../../utils/testUtils'
import Export from '../'

describe('Export component unit test coverage', () => {
  const alertList = { ...testStore.alertList }
  const store = mockStore({
    ...testStore,
    alertList: { ...alertList, currentAction: 'export' },
  })
  it('should render Export component while not loading', async () => {
    render(<Export />, { store })
    const exportComponent = screen.getByText('Export')
    await fireEvent.click(exportComponent)
    await fireEvent.click(screen.getByText('All alerts'))
    await fireEvent.click(screen.getByRole('button', { name: 'Close Modal' }))
  })
  it('should render Export component while not loading', async () => {
    render(<Export />, { store })
    const exportComponent = screen.getByText('Export')
    await fireEvent.click(exportComponent)
    await fireEvent.click(screen.getByText('All alerts'))
    await fireEvent.click(screen.getByRole('button', { name: 'Cancel' }))
  })
  it('should render Export component while not loading', async () => {
    render(<Export />, { store })
    const exportComponent = screen.getByText('Export')
    await fireEvent.click(exportComponent)
    await fireEvent.click(screen.getByText('All alerts'))
    await fireEvent.click(screen.getByRole('button', { name: 'Ok' }))
  })
})
describe('Export component unit test coverage', () => {
  const store = mockStore({
    ...testStore,
    export: {
      loading: true,
      error: '',
    },
  })
  it('should render Export component while loading', async () => {
    render(<Export />, { store })
    const exportComponent = screen.getByText('Export')
    expect(exportComponent).toBeInTheDocument()
    await fireEvent.click(exportComponent)
  })
})
