import { useState } from 'react'
import ActionBar, { Action } from '@connect/action-bar'
import ExportModal from './ExportModal'
import { useSelector, useDispatch } from 'react-redux'
import { setCurrentAction } from '../../store/reducers/AlertListSlice'
import ScreenLoader from '../ScreenLoader'

const Export = () => {
  const dispatch = useDispatch()
  const [dropVisible, setDropVisible] = useState(false)
  const { currentAction } = useSelector((state) => state.alertList)
  const { loading } = useSelector((state) => state.export)
  const [visible, setVisible] = useState(false)
  return (
    <>
      {loading && <ScreenLoader isVisible={loading} />}
      <div className="action-item-export">
        <ActionBar>
          <div>
            <Action
              label="Export"
              onClick={() => {
                setDropVisible(!dropVisible)
                dispatch(setCurrentAction('export'))
              }}
            >
              <></>
            </Action>
          </div>
        </ActionBar>
        {dropVisible && currentAction === 'export' && (
          <div className="export-dropdown">
            <span onClick={() => setVisible(true)}>All alerts</span>
          </div>
        )}
      </div>
      {visible && <ExportModal visible={visible} setVisible={setVisible} />}
    </>
  )
}

export default Export
