import Modal from '@connect/modal'
import { Paragraph } from '@connect/typography'
import { useDispatch } from 'react-redux'
import { exportAllRecords } from '.././../store/reducers/ExportSlice'
import { SORT_ORDER } from '../../constants/AppConstants'

const ExportModal = ({ visible, setVisible }) => {
  const dispatch = useDispatch()
  const sortConfigData = {
    sortField: 'CREATED_ON_DATE',
    sortOrder: SORT_ORDER.DESC,
  }
  const downloadAllRecords = async () => {
    const payload = {
      sortField: sortConfigData.sortField,
      sortOrder: sortConfigData.sortOrder,
    }
    setVisible(false)
    await dispatch(exportAllRecords(payload))
  }
  return (
    <Modal
      blocking={true}
      padded={true}
      columns={8}
      buttonPrimary={{
        label: 'Ok',
        onClick: () => downloadAllRecords(),
      }}
      buttonSecondary={{
        label: 'Cancel',
        onClick: () => setVisible(false),
      }}
      onDismiss={() => setVisible(false)}
      visible={visible}
      duration={5}
      title="Export Alert List"
    >
      <Paragraph pad={[2, 0, 0, 0]}>
        This report is intended for Internal use only. Please exercise caution
        if this will be distributed further.
      </Paragraph>
    </Modal>
  )
}

export default ExportModal
