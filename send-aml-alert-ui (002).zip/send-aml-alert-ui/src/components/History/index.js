import { Eyebrow, TypeSize } from '@connect/typography'
import { SECTIONS } from '../../constants/AppConstants'
import { historyColDef } from '../../utils/columnDefinitions'
import DataTable from '@connect/data-table'
import { useDispatch, useSelector } from 'react-redux'
import { getHistory } from '../../store/reducers/HistorySlice'
import { getSortedItems } from '../../utils/utility'
import { useEffect, useState } from 'react'

const History = ({ alertId }) => {
  const dispatch = useDispatch()
  useEffect(() => {
    const getAllHistory = async () => {
      if (alertId) {
        await dispatch(getHistory(alertId))
      }
    }
    getAllHistory()
  }, [alertId])
  const { data } = useSelector((state) => state.history)
  const [state, setState] = useState({
    items: [],
    sortReversed: false,
    sortByColumn: null,
  })

  useEffect(() => {
    if (data?.length) {
      setState({ ...state, items: data })
    }
  }, [data])

  const handleChange = async (sortByColumn, sortReversed) => {
    const items = getSortedItems({
      items: state.items,
      sortReversed,
      sortByColumn,
    })
    return setState({
      items,
      sortByColumn,
      sortReversed,
    })
  }
  return (
    <div className="section-holder" id="history-section">
      <Eyebrow size={TypeSize.Medium}>{SECTIONS.HISTORY}</Eyebrow>
      <div className="list-table">
        <div className="list-table-data">
          <DataTable
            mt={2}
            id="history-grid"
            columns={historyColDef}
            selectable={false}
            items={state.items}
            onChange={handleChange}
            sortByColumn={state.sortByColumn}
            sortReversed={state.sortReversed}
          />
        </div>
      </div>
    </div>
  )
}

export default History
