import {
  mockStore,
  render,
  screen,
  testStore,
  fireEvent,
} from '../../../utils/testUtils'
import History from '../'

describe('History component unit test coverage', () => {
  const store = mockStore(testStore)
  it('should render History component', async () => {
    render(<History alertId={'12345'} />, { store })
    const history = screen.getByText('HISTORY')
    expect(history).toBeInTheDocument()
    await fireEvent.click(screen.getByText('Date and time'))
  })
})
describe('History component unit test coverage', () => {
  const store = mockStore({ ...testStore, history: { data: [] } })
  it('should render History component if no history found', async () => {
    render(<History alertId={'12345'} />, { store })
    const history = screen.getByText('HISTORY')
    expect(history).toBeInTheDocument()
  })
})
