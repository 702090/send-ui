import DatePicker, { DatePickerVariant } from '@connect/date-picker'
import Grid, { GridColumn } from '@connect/grid'
import Input from '@connect/input'
import Selector, { SelectorVariant } from '@connect/selector'
import { sub } from 'date-fns'
import {
  FILTER_OPERATOR,
  FIELD_TYPE,
  PLACEHOLDERS,
} from '../../constants/AppConstants'

const FilterValue = ({
  data,
  index,
  onFilterValueChange,
  onDropDownFilterChange,
  onDatePickerChange,
}) => {
  const getDateError = (data) => {
    if (data.invalidDateError) {
      return data.invalidDateError
    } else {
      return !data.from ? data.fromError : ''
    }
  }
  return (
    <GridColumn size={4}>
      {data.fieldType === FIELD_TYPE.INPUT && (
        <Input
          label={index === 0 ? 'Value' : ''}
          value={data.filterValue}
          onChange={onFilterValueChange(index)}
          disabled={!data.filterOperator}
          placeholder={'Enter value'}
          error={!data.filterValue.length && data.valueError}
        />
      )}
      {data.fieldType === FIELD_TYPE.DROP_DOWN && (
        <Selector
          label={index === 0 ? 'Value' : ''}
          options={data?.filterOptions || []}
          placeholder={PLACEHOLDERS.SELECT_VALUE}
          value={data.filterValue}
          onChange={onDropDownFilterChange(index)}
          variant={SelectorVariant.Multiselect}
          error={!data.filterValue.length ? data.valueError : ''}
          disabled={!data.filterOperator}
        ></Selector>
      )}
      {data.fieldType === FIELD_TYPE.DATE_PICKER && (
        <Grid>
          <GridColumn
            size={data.filterOperator === FILTER_OPERATOR.BETWEEN ? 2 : 4}
          >
            <DatePicker
              label={index === 0 ? 'Value' : ''}
              variant={DatePickerVariant.Primary}
              onChange={onDatePickerChange(index, true)}
              selection={data.from}
              error={getDateError(data)}
              max={new Date()}
              min={sub(new Date(), { years: 10 })}
              disabled={!data.filterOperator}
              closeOnSelection
            />
          </GridColumn>
          {data.filterOperator === FILTER_OPERATOR.BETWEEN && (
            <GridColumn size={2}>
              <DatePicker
                label={index === 0 ? 'Value' : ''}
                variant={DatePickerVariant.Primary}
                onChange={onDatePickerChange(index, false)}
                selection={data.to}
                error={!data.to ? data.toError : ''}
                max={new Date()}
                min={sub(new Date(), { years: 10 })}
                disabled={!data.filterOperator}
                closeOnSelection
              />
            </GridColumn>
          )}
        </Grid>
      )}
    </GridColumn>
  )
}
export default FilterValue
