import ActionBar, { Action } from '@connect/action-bar'
import { useState } from 'react'
import FilterFields from './FilterFields'
import './style.css'
import { useDispatch, useSelector } from 'react-redux'
import { format } from 'date-fns'
import {
  FILTER_OPERATOR,
  FILTER_DATE_FORMAT,
  SEARCH_TYPE,
  SORT_ORDER,
} from '../../constants/AppConstants'
import {
  getAlertList,
  setCurrentAction,
} from '../../store/reducers/AlertListSlice'

const Filter = () => {
  const dispatch = useDispatch()
  const [pageLength, setPageLength] = useState(10)
  const [pageOffset, setPageOffset] = useState(0)
  const [showFilter, setShowFilter] = useState(false)
  const [savedFilters, setSavedFilters] = useState({})
  const [isLoading, setIsLoading] = useState(false)
  const { currentAction } = useSelector((state) => state.alertList)
  const [sortConfigData, setSortConfigData] = useState({
    sortField: 'CREATED_ON_DATE',
    sortOrder: SORT_ORDER.DESC,
  })
  const toggleFilter = () => {
    setShowFilter(!showFilter)
  }
  const handleCloseFilter = () => {
    setShowFilter(false)
  }
  const fetchAlertList = async ({
    criteria,
    criteriaIn,
    criteriaBetween,
  } = {}) => {
    const payload = {
      pageLength: pageLength,
      pageOffset: pageOffset,
      sortField: sortConfigData.sortField,
      sortOrder: sortConfigData.sortOrder,
      criteria,
      criteriaIn,
      criteriaBetween,
      exportFlag: false,
    }
    setIsLoading(true)
    await dispatch(getAlertList(payload))
  }

  const handleFiltersChangeSubmit = (filterData) => {
    setShowFilter(false)
    const postBody = {
      criteria: [],
      criteriaIn: [],
      criteriaBetween: [],
    }
    if (filterData?.length) {
      filterData.forEach((data) => {
        const payload = {
          field: data.filterName,
          operator: data.filterOperator,
        }
        if (data.searchType === SEARCH_TYPE.CRITERIA_BETWEEN) {
          payload.from = format(new Date(data.from), FILTER_DATE_FORMAT)
          payload.to =
            data.filterOperator === FILTER_OPERATOR.BETWEEN
              ? format(new Date(data.to), FILTER_DATE_FORMAT)
              : format(new Date(data.from), FILTER_DATE_FORMAT)
          payload.operator = FILTER_OPERATOR.BETWEEN
        } else {
          payload.value = data.filterValue
        }
        postBody[data.searchType].push(payload)
      })
    }
    const payload = {
      criteria: postBody.criteria.length ? postBody.criteria : null,
      criteriaIn: postBody.criteriaIn.length ? postBody.criteriaIn : null,
      criteriaBetween: postBody.criteriaBetween.length
        ? postBody.criteriaBetween
        : null,
    }
    setSavedFilters(payload)
    fetchAlertList(payload)
  }
  console.log(
    savedFilters,
    setPageLength,
    setPageOffset,
    isLoading,
    setSortConfigData
  )
  return (
    <>
      <div className="action-bar-holder">
        <ActionBar>
          <div>
            <Action
              label="Filter"
              onClick={() => {
                toggleFilter()
                dispatch(setCurrentAction('filter'))
              }}
            >
              <></>
            </Action>
          </div>
        </ActionBar>
        {showFilter && currentAction === 'filter' && (
          <div className="filter-popup" data-testid="filter-popup">
            <FilterFields
              onCancel={handleCloseFilter}
              onSubmit={handleFiltersChangeSubmit}
            />
          </div>
        )}
      </div>
    </>
  )
}
export default Filter
