import {
  mockStore,
  render,
  testStore,
  screen,
  fireEvent,
} from '../../../utils/testUtils'
import Filter from '../'
import moment from 'moment'

describe('Filter component unit test coverage', () => {
  const store = mockStore(testStore)
  it('should render Filter component', async () => {
    render(<Filter />, { store })
    const filterLink = screen.getByText(/^filter$/i)
    await fireEvent.click(filterLink)
    await fireEvent.click(screen.getByRole('button', { name: /^cancel$/i }))
  })
  it('executing filter feature for alert status', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^alert status$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^equals$/i }))
    await fireEvent.click(screen.getByText(/^select value/i))
    await fireEvent.click(screen.getByRole('button', { name: /^select all/i }))
    await fireEvent.click(screen.getByRole('button', { name: /^done$/i }))
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
  it('executing filter feature for alert status', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^rule version$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^equals$/i }))
    const valueInput = screen.getByPlaceholderText(/^enter value$/i)
    await fireEvent.change(valueInput, { target: { value: 'v1' } })
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
  it('executing filter feature for alert status and then clear filters', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^rule version$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^equals$/i }))
    const valueInput = screen.getByPlaceholderText(/^enter value$/i)
    await fireEvent.change(valueInput, { target: { value: 'v1' } })
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^clear filter$/i })
    )
  })
  it('executing filter feature for alert generated date', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^alert generation date$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^equals$/i }))
    const valueInput = screen.getByPlaceholderText(/^DD MMM YYYY$/i)
    await fireEvent.change(valueInput, {
      target: { value: moment(new Date(), 'DD MMM YYYY') },
    })
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
  it('executing filter feature for alert generated date between', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^alert generation date$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^between$/i }))
    const valueInput = screen.getAllByPlaceholderText(/^DD MMM YYYY$/i)
    await fireEvent.change(valueInput[0], {
      target: { value: moment(new Date(), 'DD MMM YYYY') },
    })
    await fireEvent.change(valueInput[1], {
      target: { value: moment(new Date(), 'DD MMM YYYY') },
    })
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
  it('executing filter feature for alert generated date between exceeding', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByText(/^select field$/i))
    await fireEvent.click(
      screen.getByRole('button', { name: /^alert generation date$/i })
    )
    await fireEvent.click(screen.getByText(/^select operator$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^between$/i }))
    const valueInput = screen.getAllByPlaceholderText(/^DD MMM YYYY$/i)
    await fireEvent.change(valueInput[0], {
      target: { value: moment(new Date(), 'DD MMM YYYY').add(2, 'days') },
    })
    await fireEvent.change(valueInput[1], {
      target: { value: moment(new Date(), 'DD MMM YYYY') },
    })
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
  it('should render Filter component with add filter', async () => {
    render(<Filter />, { store })
    const filterLink = screen.getByText(/^filter$/i)
    await fireEvent.click(filterLink)
    expect(filterLink).toBeInTheDocument()
    await fireEvent.click(screen.getByTestId('add-filter'))
    await fireEvent.click(screen.getAllByTestId('remove-filter')[1])
  })
  it('executing filter without any selections', async () => {
    render(<Filter />, { store })
    await fireEvent.click(screen.getByText(/^filter$/i))
    await fireEvent.click(screen.getByRole('button', { name: /^submit$/i }))
  })
})
