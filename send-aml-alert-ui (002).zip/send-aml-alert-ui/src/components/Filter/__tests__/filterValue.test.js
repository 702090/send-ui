import Grid from '@connect/grid'
import { screen } from '@testing-library/react'
import { render } from '../../../utils/testUtils'
import FilterValue from '../FilterValue'

const data = {
  filterName: '',
  filterOperator: '',
  filterValue: '',
  fieldType: 'datePicker',
  filterOperators: [],
  filterOptions: [],
  searchType: '',
  from: undefined,
  to: undefined,
  valueError: '',
  OperatorError: '',
  filterFieldError: '',
  fromError: '',
  toError: '',
  invalidDateError: 'some error',
}
const onFilterValueChange = jest.fn()
const onDropDownFilterChange = jest.fn()
const onDatePickerChange = jest.fn()
describe('Search component unit test coverage', () => {
  it('should render with date error', () => {
    render(
      <Grid>
        <FilterValue
          index={0}
          data={data}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
    expect(screen.getByText(/some error/i)).toBeInTheDocument()
  })
  it('should render with date error for index not 0', () => {
    render(
      <Grid>
        <FilterValue
          index={1}
          data={data}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
  })
  it('should render with date error for index not 0', () => {
    const newData = {
      ...data,
      filterOperator: 'BETWEEN',
      to: new Date(),
      from: new Date(),
    }
    render(
      <Grid>
        <FilterValue
          index={1}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
  })
  it('should render with date from error', () => {
    const newData = { ...data }
    newData.fromError = 'from error'
    newData.invalidDateError = ''
    render(
      <Grid>
        <FilterValue
          index={0}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
    expect(screen.getByText(/from error/i)).toBeInTheDocument()
  })
  it('should render input fields', () => {
    const newData = { ...data }
    newData.fieldType = 'input'
    render(
      <Grid>
        <FilterValue
          index={0}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
    expect(screen.getByRole('textbox')).toBeInTheDocument()
  })
  it('should render dropdown felids', () => {
    const newData = { ...data }
    newData.fieldType = 'dropDown'
    render(
      <Grid>
        <FilterValue
          index={0}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
  })
  it('should render between operator', () => {
    const newData = { ...data }
    newData.filterOperator = 'BETWEEN'
    render(
      <Grid>
        <FilterValue
          index={0}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
    expect(screen.getByText(/some error/i)).toBeInTheDocument()
  })
  it('should render with input for index not 0', () => {
    const newData = { ...data, fieldType: 'input' }
    render(
      <Grid>
        <FilterValue
          index={1}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
  })
  it('should render with dropdown for index not 0', () => {
    const newData = {
      ...data,
      fieldType: 'dropDown',
      filterOptions: null,
      filterValue: ['value'],
    }
    render(
      <Grid>
        <FilterValue
          index={1}
          data={newData}
          onFilterValueChange={onFilterValueChange}
          onDropDownFilterChange={onDropDownFilterChange}
          onDatePickerChange={onDatePickerChange}
        />
      </Grid>,
      {}
    )
  })
})
