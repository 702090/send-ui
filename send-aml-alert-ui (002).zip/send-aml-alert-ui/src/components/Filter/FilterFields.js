import Grid, { GridColumn, GridColumnVariant } from '@connect/grid'
import Add, { AddSize, AddVariant } from '@connect/add'
import { PLACEHOLDERS, SEARCH_TYPE } from '../../constants/AppConstants'
import {
  PLEASE_SELECT_FIELD,
  PLEASE_SELECT_OPERATOR,
  PLEASE_ENTER_VALUE,
} from '../../constants/AppErrors'
import useDate from '@connect/use-date'
import Selector from '@connect/selector'
import Button, { ButtonVariant } from '@connect/button'
import { useState, useEffect } from 'react'
import { filterConfig, filterOperations, filterRow } from './FilterConfig'
import './style.css'
import FilterValue from './FilterValue'
import { useDispatch, useSelector } from 'react-redux'
import { setFilterData } from '../../store/reducers/FilterSlice'
import _ from 'lodash'
import { validateDateFilter } from '../../utils/dateUtility'

const FilterFields = ({ onSubmit, onCancel }) => {
  const dispatch = useDispatch()
  const { filtersData, isFilterApplied } = useSelector((state) => state.filters)
  const clonedData = _.cloneDeep(filtersData)
  const [filterFormData, setFilterFormData] = useState([])
  useEffect(() => {
    setFilterFormData([...clonedData])
  }, [])
  const handleAddFilter = () => {
    setFilterFormData([...filterFormData, { ...filterRow }])
  }
  const getUpdatedFilterFormData = (index, value, filterKey) => {
    return filterFormData.map((filterData, filterFormIndex) => {
      if (index === filterFormIndex) {
        filterData[filterKey] = value
      }
      return filterData
    })
  }
  const handleFilterSubmit = () => {
    let isError = false
    const filterForm = filterFormData.map((filterData) => {
      if (!filterData.filterName) {
        isError = true
        filterData.filterFieldError = PLEASE_SELECT_FIELD
      }
      if (!filterData.filterOperator) {
        filterData.OperatorError = PLEASE_SELECT_OPERATOR
        isError = true
      }
      if (!filterData.filterValue || !filterData.filterValue.length) {
        filterData.valueError = PLEASE_ENTER_VALUE
        isError = true
      }
      if (filterData.searchType === SEARCH_TYPE.CRITERIA_BETWEEN) {
        isError = validateDateFilter(filterData)
      }
      return filterData
    })
    setFilterFormData(filterForm)
    if (!isError) {
      dispatch(
        setFilterData({ filtersData: filterForm, isFilterApplied: true })
      )
      onSubmit(filterForm)
    }
  }
  const handleDropdownFilterChange = (index) => (value) => {
    setFilterFormData(getUpdatedFilterFormData(index, value, 'filterValue'))
  }
  const handleFilterValueChange = (index) => (value) => {
    setFilterFormData(getUpdatedFilterFormData(index, value, 'filterValue'))
  }
  const handleDatePickerChange = (index, isFrom) => (value) => {
    const formattedDate = useDate(new Date(value))
    if (isFrom) {
      setFilterFormData(
        getUpdatedFilterFormData(index, formattedDate, 'filterValue')
      )
      setFilterFormData(getUpdatedFilterFormData(index, value, 'from'))
    } else {
      setFilterFormData(getUpdatedFilterFormData(index, value, 'to'))
    }
  }
  const handleFilterOperatorChange = (index) => (operator) => {
    setFilterFormData(
      getUpdatedFilterFormData(index, operator, 'filterOperator')
    )
  }
  const handleRemoveFilter = (index) => () => {
    filterFormData.splice(index, 1)
    setFilterFormData([...filterFormData])
  }
  const handleClearFilters = () => {
    dispatch(
      setFilterData({ filtersData: [{ ...filterRow }], isFilterApplied: false })
    )
    onSubmit()
  }
  const handleFilterFieldChange = (index) => (field) => {
    let updatedFilterForm
    if (field) {
      const selectedFilterOption = filterConfig.filter(
        (data) => data.value === field
      )[0]
      const operators = selectedFilterOption.OperatorList
      const operatorsList = operators.map(
        (operator) =>
          filterOperations.filter((config) => config.value === operator)[0]
      )
      updatedFilterForm = filterFormData.map((filterData, filterFormIndex) => {
        if (index === filterFormIndex) {
          filterData.filterName = selectedFilterOption.value
          filterData.filterOperators = operatorsList
          filterData.filterOperator = ''
          filterData.filterValue = []
          filterData.fieldType = selectedFilterOption.fieldType
          filterData.searchType = selectedFilterOption.searchType
          if (selectedFilterOption.filterOptions) {
            filterData.filterOptions = selectedFilterOption.filterOptions
          }
        }
        return filterData
      })
    } else {
      updatedFilterForm = filterFormData.map((filterData, filterFormIndex) => {
        if (index === filterFormIndex) {
          return { ...filterRow }
        }
        return filterData
      })
    }
    setFilterFormData(updatedFilterForm)
  }
  return (
    <div className="filter-panel">
      <Grid>
        <GridColumn variant={GridColumnVariant.Panel} pad={3}>
          <Grid>
            {filterFormData.map((data, index) => (
              <GridColumn key={index} pb={2}>
                <Grid>
                  <GridColumn size={4}>
                    <Selector
                      data-testid="dropdown-filter"
                      label={index === 0 ? 'Field' : ''}
                      options={filterConfig}
                      placeholder={PLACEHOLDERS.SELECT_FIELD}
                      value={data.filterName}
                      onChange={handleFilterFieldChange(index)}
                      error={!data.filterName ? data.filterFieldError : ''}
                    ></Selector>
                  </GridColumn>
                  <GridColumn size={3}>
                    <Selector
                      label={index === 0 ? 'Operator' : ''}
                      options={data.filterOperators}
                      placeholder={PLACEHOLDERS.SELECT_OPERATOR}
                      value={data.filterOperator}
                      onChange={handleFilterOperatorChange(index)}
                      error={!data.filterOperator ? data.OperatorError : ''}
                      disabled={!data.filterName}
                    ></Selector>
                  </GridColumn>
                  <FilterValue
                    index={index}
                    data={data}
                    onFilterValueChange={handleFilterValueChange}
                    onDropDownFilterChange={handleDropdownFilterChange}
                    onDatePickerChange={handleDatePickerChange}
                  />
                  <GridColumn size={1} pt={index === 0 ? 4.5 : 1.5}>
                    <div className="add-remove-block">
                      <div
                        data-testid="remove-filter"
                        onClick={
                          filterFormData.length !== 1
                            ? handleRemoveFilter(index)
                            : undefined
                        }
                        className={
                          filterFormData.length === 1 ? 'disabled-icon' : ''
                        }
                      >
                        <Add
                          variant={AddVariant.Remove}
                          size={AddSize.Medium}
                        ></Add>
                      </div>
                      <div
                        data-testid="add-filter"
                        onClick={
                          filterFormData.length === index + 1
                            ? handleAddFilter
                            : undefined
                        }
                        className={
                          filterFormData.length !== index + 1
                            ? 'disabled-icon'
                            : ''
                        }
                      >
                        <Add
                          variant={AddVariant.Add}
                          size={AddSize.Medium}
                        ></Add>
                      </div>
                    </div>
                  </GridColumn>
                </Grid>
              </GridColumn>
            ))}
            <GridColumn>
              <div className="filter-btn">
                <Button mr={2} onClick={() => handleFilterSubmit()}>
                  Submit
                </Button>
                <Button
                  mr={2}
                  variant={ButtonVariant.Secondary}
                  disabled={!isFilterApplied}
                  onClick={() => handleClearFilters()}
                >
                  Clear Filter
                </Button>
                <Button
                  variant={ButtonVariant.Secondary}
                  onClick={() => onCancel()}
                >
                  Cancel
                </Button>
              </div>
            </GridColumn>
          </Grid>
        </GridColumn>
      </Grid>
    </div>
  )
}
export default FilterFields
