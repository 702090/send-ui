export const alertStatusList = [
  {
    label: 'New',
    value: 'new',
  },
  {
    label: 'Open',
    value: 'open',
  },
  {
    label: 'Closed',
    value: 'closed',
  },
]

export const alertTypeList = [
  {
    label: 'Daily',
    value: 'Daily',
  },
  {
    label: 'Weekly',
    value: 'Weekly',
  },
  {
    label: 'Monthly',
    value: 'Monthly',
  },
]

export const networkList = [
  {
    label: 'Credit',
    value: 'Credit',
  },
  {
    label: 'Debit',
    value: 'Debit',
  },
]

export const XBorDOMList = [
  {
    label: 'XB',
    value: 'XB',
  },
  {
    label: 'DOM',
    value: 'DOM',
  },
]

export const oiRiList = [
  {
    label: 'OI',
    value: 'OI',
  },
  {
    label: 'RI',
    value: 'RI',
  },
]
