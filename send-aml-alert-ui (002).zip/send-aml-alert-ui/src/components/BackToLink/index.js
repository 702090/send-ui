import Link, { LinkVariant } from '@connect/link'

const BackToLink = ({ linkText, route }) => {
  return (
    <Link
      variant={LinkVariant.Back}
      aria-label={linkText}
      softNavigate={false}
      href={route}
    >
      {linkText}
    </Link>
  )
}
export default BackToLink
