import { render, screen } from '../../../utils/testUtils'
import BackToLink from '../'

describe('Back to link component test cases', () => {
  test('Verify Back to link is getting rendered correctly', () => {
    render(<BackToLink linkText={'title'} route={'../'} />, {})
    expect(screen.getByText('title')).toBeInTheDocument()
  })
})
