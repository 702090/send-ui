import { render, screen } from '../../../utils/testUtils'
import ScreenLoader from '../'

describe('Screen Loader component test cases', () => {
  test('Verify ScreenLoader is getting rendered correctly', async () => {
    render(<ScreenLoader />, {})
    const component = screen.getByTestId('spinner-holder-full')
    expect(component).toBeInTheDocument()
  })
})
