import Spinner from '@connect/spinner'

const ScreenLoader = ({ isVisible }) => {
  return (
    <div className="spinner-holder-full" data-testid="spinner-holder-full">
      <Spinner visible={isVisible} />
    </div>
  )
}

export default ScreenLoader
