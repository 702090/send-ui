import './style.css'

const NoRecordsHolder = ({ section }) => {
  return (
    <div className="no-records-holder">
      <p>No {section} found</p>
    </div>
  )
}

export default NoRecordsHolder
