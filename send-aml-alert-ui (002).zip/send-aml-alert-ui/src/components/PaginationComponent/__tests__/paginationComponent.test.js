import { render, screen, fireEvent } from '../../../utils/testUtils'
import PaginationComponent from '../'

describe('PaginationComponent component test cases', () => {
  test('Verify PaginationComponent is getting rendered with default', async () => {
    render(<PaginationComponent setPage={jest.fn()} />, {})
    const nexBtn = screen.getByRole('button', { name: /Go to next page/i })
    expect(nexBtn).toBeInTheDocument()
    await fireEvent.click(nexBtn)
  })
  test('Verify PaginationComponent is getting rendered correctly', async () => {
    render(
      <PaginationComponent
        setPage={jest.fn()}
        page={1}
        pageSize={5}
        total={10}
      />,
      {}
    )
    const nexBtn = screen.getByRole('button', { name: /Go to next page/i })
    expect(nexBtn).toBeInTheDocument()
    await fireEvent.click(nexBtn)
  })
})
