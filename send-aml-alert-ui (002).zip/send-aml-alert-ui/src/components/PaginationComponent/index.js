import Pagination from '@connect/pagination'

const PaginationComponent = ({
  page = 1,
  pageSize = 10,
  total = 10,
  setPage,
}) => {
  return (
    <div className="pagination-component" data-testid="pagination-component">
      <Pagination
        page={page}
        pageSize={pageSize}
        total={total}
        onChange={(val) => {
          setPage(val)
        }}
      />
    </div>
  )
}

export default PaginationComponent
