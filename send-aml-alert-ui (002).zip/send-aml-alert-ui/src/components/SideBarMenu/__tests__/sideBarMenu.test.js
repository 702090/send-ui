import { render, screen, fireEvent } from '../../../utils/testUtils'
import SideBarMenu from '../'
import { alertDetailsSideBarMenus } from '../../../utils/sideBarMenuItems'

describe('Side bar menu component test cases', () => {
  beforeEach(() => {
    render(
      <SideBarMenu
        sideBarMenus={alertDetailsSideBarMenus}
        pageName="alertDetails"
      />
    )
  })
  afterEach(() => {
    jest.clearAllMocks()
  })
  test('Renders Side Bar for details Component component', () => {
    expect(screen.getByTestId('sidebar-menu')).toBeInTheDocument()
  })
  test('Renders Side Bar for details Component component', async () => {
    const boundingClientMock = jest.fn().mockReturnValue({ top: 10, height: 0 })
    jest.spyOn(document, 'querySelector').mockImplementation(() => ({
      getBoundingClientRect: boundingClientMock,
    }))
    global.setTimeout = jest.fn((cb) => cb())
    await fireEvent.click(screen.getByText('History'), {
      target: { innerText: 'History' },
    })
    expect(boundingClientMock).toBeCalledTimes(1)
  })
  test('test handleMenuSelectionOnScroll method', async () => {
    const boundingClientMock = jest
      .fn()
      .mockReturnValue({ top: 200, height: 100 })
    jest.spyOn(document, 'getElementById').mockImplementation(() => ({
      getBoundingClientRect: boundingClientMock,
      style: { position: 'fixed' },
    }))
    global.setTimeout = jest.fn((cb) => cb())
    global.scrollY = 200
    await fireEvent.scroll(document, {
      target: { pageXOffset: 300, pageYOffset: 1050 },
    })
  })
  test('test handleMenuSelectionOnScroll method', async () => {
    const boundingClientMock = jest
      .fn()
      .mockReturnValue({ top: 200, height: 100 })
    jest.spyOn(document, 'getElementById').mockImplementation(() => ({
      getBoundingClientRect: boundingClientMock,
      style: { position: 'fixed' },
    }))
    global.setTimeout = jest.fn((cb) => cb())
    global.scrollY = 200
    await fireEvent.click(screen.getByText('History'), {
      target: { innerText: 'History' },
    })
    await fireEvent.scroll(document, {
      target: { pageXOffset: 300, pageYOffset: 1050 },
    })
  })
})
