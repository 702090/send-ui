import Tabs, { TabContent, TabsVariant } from '@connect/tabs'
import { useState, useEffect } from 'react'
import {
  GRIP_SCROLLER_TOP,
  DEFAULT_FOR_TOP_MENU,
  GRIP_CLICKER_TOP,
  SCROLL_TIME_TAKEN,
} from '../../constants/AppConstants'

const SideBarMenu = ({ sideBarMenus, pageName }) => {
  const [clickDetected, setClickDetected] = useState(false)
  useEffect(() => {
    document.addEventListener('scroll', handleMenuSelectionOnScroll)
    return () => {
      document.removeEventListener('scroll', handleMenuSelectionOnScroll)
    }
  }, [window.scrollY, clickDetected])
  const [activeTab, setActiveTab] = useState(0)

  const onTabClick = async (e) => {
    setClickDetected(true)
    const targetId = sideBarMenus.find(
      (item) => item.title === e.target.innerText
    ).url
    const scrollElement = document.querySelector(targetId)
    const y = scrollElement?.getBoundingClientRect().top + window.scrollY
    window.scroll({
      top: y - GRIP_CLICKER_TOP[pageName],
      behavior: 'smooth',
    })
    setTimeout(() => {
      setClickDetected(false)
    }, SCROLL_TIME_TAKEN)
  }
  const handleMenuSelectionOnScroll = () => {
    if (!clickDetected) {
      sideBarMenus.forEach((menu) => {
        const id = menu.url.substring(1, menu.url.length)
        const windowTop = window.scrollY + GRIP_SCROLLER_TOP[pageName]
        const element = document.getElementById(id)
        if (element) {
          const rect = element.getBoundingClientRect()
          const elementTop = window.scrollY + rect.top
          const elementBottom = elementTop + rect.height
          if (windowTop <= DEFAULT_FOR_TOP_MENU[pageName]) {
            setActiveTab(0)
          } else if (
            windowTop >= elementTop &&
            windowTop <= elementBottom &&
            sideBarMenus[activeTab].title !== menu.title
          ) {
            const index = sideBarMenus.map((e) => e.title).indexOf(menu.title)
            setActiveTab(index)
          }
        }
      })
    }
  }

  return (
    <div data-testid="sidebar-menu" className="sidebar-menu">
      <Tabs
        activeTab={activeTab}
        onChange={setActiveTab}
        onClick={(e) => onTabClick(e)}
        variant={TabsVariant.Vertical}
      >
        {sideBarMenus.map((menuItem) => (
          <TabContent key={menuItem.title} label={menuItem.title}></TabContent>
        ))}
      </Tabs>
    </div>
  )
}

export default SideBarMenu
