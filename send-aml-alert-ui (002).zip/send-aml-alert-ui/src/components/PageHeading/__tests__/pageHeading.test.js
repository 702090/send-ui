import { render, screen } from '../../../utils/testUtils'
import PageHeading from '../'

describe('PageHeading component test cases', () => {
  test('Verify PageHeading is getting rendered correctly', () => {
    render(<PageHeading linkText={'Test heading'} />, {})
    expect(screen.getByTestId('heading-wrapper-component')).toBeInTheDocument()
  })
})
