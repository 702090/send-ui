import { DisplayHeading3 } from '@connect/typography'

const PageHeading = ({ title }) => {
  return (
    <div
      className="page-heading-wrapper"
      data-testid="heading-wrapper-component"
    >
      <DisplayHeading3>{title}</DisplayHeading3>
    </div>
  )
}

export default PageHeading
