import Modal from '@connect/modal'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import TextArea from '@connect/text-input'
import { addNewComment } from '../../store/reducers/CommentsSlice'
import { toastSetter } from '../../utils/utility'

const AddCommentModal = ({
  visibility,
  setVisibility,
  alertId,
  getComments,
}) => {
  const dispatch = useDispatch()
  const [comment, setComment] = useState('')
  const handleButtonPrimaryClick = async () => {
    const payload = {
      alertId: alertId,
      commentText: comment,
    }
    setVisibility(false)
    const res = await dispatch(addNewComment({ payload }))
    toastSetter({
      type: res.type,
      success: 'Comment added successfully',
      error: 'Failed to add comment',
      dispatch,
    })
    await dispatch(getComments(alertId))
  }
  const handleButtonSecondaryClick = () => {
    setVisibility(false)
  }
  return (
    <Modal
      buttonPrimary={{
        label: 'Add',
        onClick: () => handleButtonPrimaryClick(),
      }}
      buttonSecondary={{
        label: 'Cancel',
        onClick: () => handleButtonSecondaryClick(),
      }}
      onDismiss={() => setVisibility(false)}
      title="Add Comment"
      visible={visibility}
    >
      <div className="comments-text">
        <TextArea
          onChange={setComment}
          value={comment}
          autoFocus={true}
          name="add-comment-text"
          rows={4}
          placeholder="Add your comments here"
        />
      </div>
    </Modal>
  )
}

export default AddCommentModal
