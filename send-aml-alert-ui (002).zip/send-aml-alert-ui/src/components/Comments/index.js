import { Eyebrow, TypeSize, HorizontalRule } from '@connect/typography'
import { SECTIONS, BUTTONS } from '../../constants/AppConstants'
import Link, { LinkVariant } from '@connect/link'
//import { formatTableDate } from '../../utils/dateUtility'
import moment from 'moment'
import './style.css'
import { useDispatch, useSelector } from 'react-redux'
import { getComments } from '../../store/reducers/CommentsSlice'
import { useEffect, useState } from 'react'
import NoRecordsHolder from '../NoRecordsHolder'
import AddCommentModal from './AddCommentModal'
import SectionLoader from '../SectionLoader'

const Comments = ({ alertId }) => {
  const dispatch = useDispatch()
  const [visibility, setVisibility] = useState(false)
  useEffect(() => {
    const getAllComments = async () => {
      if (alertId) {
        await dispatch(getComments(alertId))
      }
    }
    getAllComments()
  }, [alertId])
  const { data, loading } = useSelector((state) => state.comments)
  const openAddCommentModal = () => {
    setVisibility(true)
  }

  return (
    <div className="section-holder" id="comments-section">
      {loading && <SectionLoader isVisible={loading} />}
      <Eyebrow size={TypeSize.Medium}>{SECTIONS.COMMENTS}</Eyebrow>
      <div className="right-add-button-holder">
        <Link
          type="button"
          style={{ textDecoration: 'none' }}
          variant={LinkVariant.Add}
          onClick={() => openAddCommentModal()}
        >
          {BUTTONS.ADD_COMMENT}
        </Link>
      </div>
      <div className="comments-list">
        {data.length > 0 ? (
          <>
            <div style={{ marginBottom: '15px' }}>
              {data.map(
                ({ commentId, createdById, createdOnDate, commentText }) => (
                  <div key={commentId} className="comment-block">
                    <HorizontalRule />
                    <div className="user-name">{createdById}</div>
                    <div className="date-time">
                      {moment(createdOnDate).format('DD MMM YYYY, hh:mm a')}
                    </div>
                    <div className="text-comment">{commentText}</div>
                  </div>
                )
              )}
            </div>
            <HorizontalRule />
          </>
        ) : (
          <NoRecordsHolder section="comments" />
        )}
      </div>
      {visibility && (
        <AddCommentModal
          visibility={visibility}
          setVisibility={setVisibility}
          alertId={alertId}
          getComments={getComments}
        />
      )}
    </div>
  )
}
export default Comments
