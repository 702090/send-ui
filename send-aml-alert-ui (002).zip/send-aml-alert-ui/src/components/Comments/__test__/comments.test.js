import {
  render,
  fireEvent,
  screen,
  mockStore,
  testStore,
} from '../../../utils/testUtils'
import Comments from '../'
describe('Comments component test cases', () => {
  const store = mockStore({ ...testStore, comments: { data: [] } })
  test('Comments is getting rendered correctly with cancel click', async () => {
    render(<Comments alertId="SEN-12345" />, { store })
  })
})
describe('Comments component test cases', () => {
  const store = mockStore(testStore)
  test('Comments is getting rendered correctly with cancel click', async () => {
    render(<Comments alertId="SEN-12345" />, { store })
    await fireEvent.click(screen.getByText(/^add comment$/i))
    await fireEvent.click(screen.getByRole('button', { name: /Cancel/i }))
  })
  test('Comments is getting rendered correctly with close click', async () => {
    render(<Comments alertId="SEN-12345" />, { store })
    await fireEvent.click(screen.getByText(/^add comment$/i))
    await fireEvent.click(screen.getByRole('button', { name: /Close Modal/i }))
  })
  test('Comments is getting rendered correctly with add click', async () => {
    render(<Comments alertId="SEN-12345" />, { store })
    await fireEvent.click(screen.getByText(/^add comment$/i))
    const textarea = screen.getByPlaceholderText('Add your comments here')
    await fireEvent.change(textarea, { target: { value: 'test comments' } })
    await fireEvent.click(screen.getByRole('button', { name: 'Add' }))
  })
})
