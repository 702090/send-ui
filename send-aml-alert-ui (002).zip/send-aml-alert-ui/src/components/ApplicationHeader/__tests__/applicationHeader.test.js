import { render, screen } from '../../../utils/testUtils'
import ApplicationHeader from '../'
import { APP_HEADER } from '../../../constants/AppConstants'

describe('ApplicationHeader component test cases', () => {
  test('ApplicationHeader is getting rendered correctly', () => {
    render(<ApplicationHeader />, {})
    expect(screen.getByText('Alerts')).toBeInTheDocument()
    expect(screen.getByText(APP_HEADER)).toBeInTheDocument()
  })
})
