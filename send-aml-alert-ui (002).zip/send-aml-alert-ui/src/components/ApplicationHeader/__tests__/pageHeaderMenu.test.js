import { render } from '../../../utils/testUtils'
import PageHeaderMenu from '../PageHeaderMenu'

describe('PageHeaderMenu component test cases', () => {
  test('PageHeaderMenu is getting rendered correctly with valid link', () => {
    const menu = [
      {
        header: 'Alerts',
        url: '/alerts',
        isActive: true,
        subPaths: ['alerts'],
      },
    ]
    render(<PageHeaderMenu menuItems={menu} />, {})
  })
  test('PageHeaderMenu is getting rendered correctly with empty link', () => {
    const menu = [
      {
        header: 'Alerts',
        url: '/alerts',
        isActive: true,
        subPaths: [''],
      },
    ]
    render(<PageHeaderMenu menuItems={menu} />, {})
  })
})
