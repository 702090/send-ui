import { NavLink } from 'react-router-dom'

const PageHeaderMenu = ({ menuItems }) => {
  const activeMenuStyle = {
    color: '#fff',
    textDecoration: 'none',
    padding: '0.44rem 0 0.375rem',
    marginRight: '32px',
    borderBottom: '4px solid white',
    marginBottom: '25px',
    fontFamily:
      'MarkForMC-Med,-apple-system,system-ui,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif',
  }

  const menuStyle = {
    color: '#fff',
    textDecoration: 'none',
    padding: '0.44rem 0 0.375rem',
    marginRight: '32px',
    fontFamily:
      'MarkForMC-Med,-apple-system,system-ui,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif',
  }

  return (
    <div className="page-header-menu" data-testid="page-header-component">
      {menuItems.map((menuItem) => (
        <NavLink
          to={menuItem.url}
          key={menuItem.header}
          data-testid={menuItem.header}
          style={menuStyle}
          activeStyle={activeMenuStyle}
          isActive={(match, location) => {
            if (menuItem.subPaths.includes(location.pathname.split('/')[1])) {
              return true
            }
            return !match && false
          }}
        >
          {menuItem.header}
        </NavLink>
      ))}
    </div>
  )
}

export default PageHeaderMenu
