import { APP_HEADER } from '../../constants/AppConstants'
import PageHeader from '@connect/page-header'
import PageHeaderMenu from './PageHeaderMenu'
import { menuItems } from '../../constants/MenusLists'

const ApplicationHeader = () => {
  return (
    <div className="header-wrapper">
      <div className="connect-page-header">
        <PageHeader title={APP_HEADER} />
      </div>
      <div className="header-menu-wrapper">
        <PageHeaderMenu menuItems={menuItems} />
      </div>
    </div>
  )
}

export default ApplicationHeader
