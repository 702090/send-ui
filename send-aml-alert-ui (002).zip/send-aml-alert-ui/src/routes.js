import { ROUTES_PATH } from './constants/ApiRoutes'
import AlertListMain from './pages/alert-list/AlertListMain'
import AlertDetailsMain from './pages/alert-details/AlertDetailsMain'
import { LINKS } from './constants/AppConstants'

export const internalRoutes = [
  {
    key: 'alerts',
    path: ROUTES_PATH.alertList,
    renderComponent: (crumbs) => <AlertListMain crumbItem={crumbs} />,
    crumbs: [
      {
        selected: 'true',
        link: ROUTES_PATH.alertList,
        accessibilityText: LINKS.ALERT_LIST,
      },
    ],
  },
  {
    key: 'alertsDetails',
    path: ROUTES_PATH.alertDetails,
    renderComponent: (crumbs) => <AlertDetailsMain crumbItem={crumbs} />,
    crumbs: [
      {
        selected: 'false',
        link: ROUTES_PATH.alertDetails,
        accessibilityText: LINKS.ALERT_DETAILS,
      },
    ],
  },
]
