import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {
  getAlertList,
  downloadAlertFile,
  updateColumns,
} from '../../store/reducers/AlertListSlice'
import { indexedWithId } from '../../utils/utility'
import ScreenLoader from '../../components/ScreenLoader'
import PaginationComponent from '../../components/PaginationComponent'
import PageSizeSelector from '../../components/PageSizeSelector'
import DataTable from '@connect/data-table'
import NoRecordsHolder from '../../components/NoRecordsHolder'
import { LABEL_MAPPER } from '../../constants/AppConstants'

const AlertListTable = () => {
  const dispatch = useDispatch()
  const [pageLength, setPageLength] = useState(10)
  const [pageOffset, setPageOffset] = useState(0)
  const [totalAlertCount, setTotalAlertCount] = useState(0)
  const [state, setState] = useState({
    items: [],
    selectedAll: false,
    selections: [],
    sortReversed: false,
    sortByColumn: null,
  })
  const { details, loading, columns } = useSelector((state) => state.alertList)
  useEffect(() => {
    if (details?.items?.length) {
      setState({ ...state, items: indexedWithId(details.items, 'alertId') })
    }
  }, [details?.items])
  const fetchAlertList = async () => {
    const payload = {
      pageLength: 10,
      pageOffset: 0,
      sortField: 'CREATED_ON_DATE',
      sortOrder: 'DESC',
    }
    await dispatch(getAlertList(payload))
    setTotalAlertCount(details.total)
  }
  useEffect(() => {
    fetchAlertList()
  }, [])
  const handleChange = () => {
    // no action
  }
  const handlePageSizeChange = (pageLength) => {
    setPageOffset(0)
    setPageLength(pageLength)
  }
  const handlePageChange = (pageOffset) => {
    setPageOffset(pageOffset)
  }
  const initializeColumns = () => {
    const listColumns = [
      ...columns,
      {
        itemKey: 'fileName',
        label: LABEL_MAPPER.fileName,
        sortable: true,
        grow: 6,
        onRender: (params) => {
          return (
            <b
              style={{
                color: '#cf4500',
                fontWeight: '600px',
                cursor: 'pointer',
              }}
              onClick={() =>
                dispatch(downloadAlertFile({ fileName: params.fileName }))
              }
            >
              {params.fileName}
            </b>
          )
        },
      },
    ]
    dispatch(updateColumns(listColumns))
  }
  useEffect(() => {
    initializeColumns()
  }, [])
  return (
    <div className="list-table-wrapper">
      {loading && <ScreenLoader isVisible={loading} />}
      <>
        {details?.items?.length ? (
          <div data-testid="list-table-component" className="list-table">
            <div className="list-table-data">
              <DataTable
                id={name}
                onChange={handleChange}
                columns={columns}
                items={state.items}
                selectable={true}
                selectedAll={state.selectedAll}
                selections={state.selections}
                sortReversed={state.sortReversed}
                sortByColumn={state.sortByColumn}
                resetSelectionOnHeaderClick={true}
                isStickyHeader={true}
              />
            </div>
          </div>
        ) : (
          <NoRecordsHolder section="alerts" />
        )}
        {state.items.length > 0 && (
          <div className="pagination-div" data-testid="pagination-component">
            <PaginationComponent
              page={pageOffset + 1}
              pageSize={pageLength}
              total={totalAlertCount}
              setPage={handlePageChange}
            />
            <PageSizeSelector
              pageLength={pageLength}
              setPageSize={handlePageSizeChange}
              defaultValue={10}
            />
          </div>
        )}
      </>
    </div>
  )
}

export default AlertListTable
