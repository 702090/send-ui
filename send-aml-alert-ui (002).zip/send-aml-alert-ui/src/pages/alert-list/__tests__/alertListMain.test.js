import AlertListMain from '../AlertListMain'
import {
  mockStore,
  testStore,
  render,
  screen,
  fireEvent,
} from '../../../utils/testUtils'
import { LINKS } from '../../../constants/AppConstants'

describe('AlertListMain component test cases', () => {
  const store = mockStore(testStore)
  test('AlertListMain renders BackToLink and PageHeading with correct props', () => {
    render(<AlertListMain />, { store })
    const backToLink = screen.getByText(LINKS.HOME)
    expect(backToLink).toBeInTheDocument()
    const pageHeading = screen.getByText(LINKS.ALERT_LIST)
    expect(pageHeading).toBeInTheDocument()
  })
  test('AlertListMain renders screen by using searchAlertById', async () => {
    render(<AlertListMain />, { store })
    const searchInput = screen.getByPlaceholderText('Search by alert id')
    await fireEvent.change(searchInput, { target: { value: 'TEST-171-705' } })
    await fireEvent.change(searchInput, { target: { value: '' } })
    fireEvent.keyPress(searchInput, { key: 'Enter', charCode: 13 })
  })
  test('AlertListMain renders screen after changing page length', async () => {
    render(<AlertListMain />, { store })
    const input = screen.getByDisplayValue(10)
    await fireEvent.change(input, { target: { value: 25 } })
  })
  test('AlertListMain renders screen after changing page length', async () => {
    render(<AlertListMain />, { store })
    await fireEvent.click(
      screen.getByRole('button', { name: /Go to next page/i })
    )
  })
})
describe('AlertListMain component test cases', () => {
  const store = mockStore({
    ...testStore,
    alertList: {
      ...testStore.alertList,
      details: { items: [] },
      loading: true,
    },
  })
  test('AlertListMain with no items', () => {
    render(<AlertListMain />, { store })
  })
})
