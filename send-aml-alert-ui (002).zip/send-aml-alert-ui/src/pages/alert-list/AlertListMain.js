import BackToLink from '../../components/BackToLink'
import Filter from '../../components/Filter'
import ColumnSelector from '../../components/ColumnSelector'
import PageHeading from '../../components/PageHeading'
import SearchBar from '../../components/SearchBar'
import { LINKS } from '../../constants/AppConstants'
import { PLACEHOLDERS } from '../../constants/AppConstants'
import AlertListTable from './AlertListTable'
import { getAlertList } from '../../store/reducers/AlertListSlice'
import { useDispatch } from 'react-redux'
import Export from '../../components/Export'

const AlertListMain = () => {
  const dispatch = useDispatch()
  const searchAlertById = (id) => {
    const payload = {
      criteria: [{ field: 'ALERT_ID', operator: 'CONTAINS', value: id }],
      pageLength: 10,
      pageOffset: 0,
      sortField: 'CREATED_ON_DATE',
      sortOrder: 'DESC',
    }
    if (!id) {
      delete payload.criteria
    }
    dispatch(getAlertList(payload))
  }
  return (
    <div>
      <div className="fixed-top-wrapper">
        <BackToLink linkText={LINKS.HOME} />
        <PageHeading title={LINKS.ALERT_LIST} />
      </div>
      <div className="after-header-screen-wrapper">
        <SearchBar
          placeholderText={PLACEHOLDERS.SEARCH_ALERTS}
          onSearch={searchAlertById}
        />
        <div className="action-panel-holder">
          <Filter />
          <ColumnSelector />
          <Export />
        </div>
        <AlertListTable />
      </div>
    </div>
  )
}
export default AlertListMain
