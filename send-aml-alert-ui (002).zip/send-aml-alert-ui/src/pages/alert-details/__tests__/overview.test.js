import React from 'react'
import { render, testStore, mockStore } from '../../../utils/testUtils'
import Overview from '../Overview'

describe('Overview Details Component', () => {
  const store = mockStore(testStore)
  test('overview with alertId', async () => {
    render(<Overview alertId="SEN-1234" />, { store })
  })
})
describe('Overview Details Component on loading', () => {
  const store = mockStore({
    ...testStore,
    alertDetails: {
      data: { alertGenerationDate: '2024-06-12T15:59:01.060-05:00' },
      loading: true,
    },
  })
  test('overview with alertId', async () => {
    render(<Overview alertId="SEN-1234" />, { store })
  })
})
