import React from 'react'
import {
  render,
  fireEvent,
  screen,
  testStore,
  mockStore,
} from '../../../utils/testUtils'
import AlertDetailsMain from '../AlertDetailsMain'

describe('AlertDetailsMain Component', () => {
  const store = mockStore(testStore)
  test('clicking save button triggers save function', async () => {
    render(<AlertDetailsMain />, { store })
    await fireEvent.click(screen.getByRole('button', { name: /^save/i }))
  })
})
