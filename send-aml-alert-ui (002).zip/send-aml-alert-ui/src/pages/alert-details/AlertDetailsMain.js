import BackToLink from '../../components/BackToLink'
import PageHeading from '../../components/PageHeading'
import SideBarMenu from '../../components/SideBarMenu'
import Comments from '../../components/Comments'
import Attachments from '../../components/Attachments'
import History from '../../components/History'
import Overview from './Overview'
import { LINKS } from '../../constants/AppConstants'
import { alertDetailsSideBarMenus } from '../../utils/sideBarMenuItems'
import Button from '@connect/button'
import { getIdFromURL } from '../../utils/utility'

const AlertDetailsMain = () => {
  const alertId = getIdFromURL()
  return (
    <div>
      <div className="fixed-top-wrapper">
        <BackToLink linkText={LINKS.ALERT_LIST} route={'../alerts'} />
        <PageHeading title={LINKS.ALERT_DETAILS} />
      </div>
      <div className="after-header-screen-wrapper">
        <SideBarMenu
          sideBarMenus={alertDetailsSideBarMenus}
          pageName={'alertDetails'}
        />
        <div className="page-button-holders assign">
          <Button onClick={() => {}}>Assign</Button>
        </div>
        <div className="page-button-holders close">
          <Button onClick={() => {}}>Close</Button>
        </div>
        <div className="details-section-scrollable">
          <Overview alertId={alertId} />
          <Comments alertId={alertId} />
          <Attachments alertId={alertId} />
          <History alertId={alertId} />
        </div>
      </div>
    </div>
  )
}
export default AlertDetailsMain
