import { Eyebrow, TypeSize } from '@connect/typography'
import { SECTIONS, LABEL_MAPPER, NO_VAL } from '../../../constants/AppConstants'
import Grid, { GridColumn } from '@connect/grid'
import LabelGenerator from '../../../components/LabelGenerator'
import Link from '@connect/link'
import { useDispatch, useSelector } from 'react-redux'
import { useEffect } from 'react'
import { getAlertDetails } from '../../../store/reducers/AlertDetailsSlice'
import moment from 'moment'
import ScreenLoader from '../../../components/ScreenLoader'

const Overview = ({ alertId }) => {
  const dispatch = useDispatch()
  useEffect(() => {
    const fetchAlertDetails = async () => {
      if (alertId) {
        await dispatch(getAlertDetails(alertId))
      }
    }
    fetchAlertDetails()
  }, [alertId])
  const { data, loading } = useSelector((state) => state.alertDetails)
  return (
    <div className="section-holder" id="overview-section">
      {loading && <ScreenLoader isVisible={loading} />}
      <Eyebrow size={TypeSize.Medium}>{SECTIONS.OVERVIEW}</Eyebrow>
      <Grid responsive={true}>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.alertId} isRequired={false} />
          <div className="general-value">{data?.alertId || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator
            value={LABEL_MAPPER.alertGenerationDate}
            isRequired={false}
          />
          <div className="general-value">
            {data?.alertGenerationDate
              ? moment(data.alertGenerationDate).format('DD MMM YYYY')
              : NO_VAL}
          </div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.alertMonth} isRequired={false} />
          <div className="general-value">{data?.alertMonth || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.alertYear} isRequired={false} />
          <div className="general-value">{data?.alertYear || NO_VAL}</div>
        </GridColumn>
      </Grid>
      <Grid responsive={true}>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.alertStatus} isRequired={false} />
          <div className="general-value">{data?.alertStatus || NO_VAL}</div>
        </GridColumn>

        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.alertType} isRequired={false} />
          <div className="general-value">{data?.alertType || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.rule} isRequired={false} />
          <div className="general-value">{data?.rule || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.ruleVersion} isRequired={false} />
          <div className="general-value">{data?.ruleVersion || NO_VAL}</div>
        </GridColumn>
      </Grid>
      <Grid responsive={true}>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.mccCode} isRequired={false} />
          <div className="general-value">{data?.mccCode || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator
            value={LABEL_MAPPER.transactionType}
            isRequired={false}
          />
          <div className="general-value">
            <Link> {data?.transactionType || NO_VAL}</Link>
          </div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator
            value={LABEL_MAPPER.transactionTypeIdentifier}
            isRequired={false}
          />
          <div className="general-value">
            {data?.transactionTypeIdentifier || NO_VAL}
          </div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.network} isRequired={false} />
          <div className="general-value">{data?.network || NO_VAL}</div>
        </GridColumn>
      </Grid>
      <Grid responsive={true}>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.region} isRequired={false} />
          <div className="general-value">{data?.region || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.country} isRequired={false} />
          <div className="general-value">{data?.country || NO_VAL}</div>
        </GridColumn>
        <GridColumn size={3} mt={3}>
          <LabelGenerator value={LABEL_MAPPER.XbOrDom} isRequired={false} />
          <div className="general-value">{data?.xbOrDom || NO_VAL}</div>
        </GridColumn>
      </Grid>
    </div>
  )
}
export default Overview
