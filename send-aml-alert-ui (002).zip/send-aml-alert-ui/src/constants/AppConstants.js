export const APP_HEADER = 'Send AML Transaction Alerts'
export const LINKS = {
  HOME: 'Home',
  BACK: 'Back',
  ALERT_LIST: 'Alert list',
  ALERT_DETAILS: 'Alert details',
}
export const PLACEHOLDERS = {
  SEARCH_ALERTS: 'Search by alert id',
  SELECT_A_CATEGORY: 'Select a category',
  SELECT_CATEGORY: 'Select category',
  SELECT_OPERATOR: 'Select operator',
  SELECT_FIELD: 'Select Field',
  SELECT_VALUE: 'Select Value',
}

export const SEARCH_TYPE = {
  CRITERIA: 'criteria',
  CRITERIA_BETWEEN: 'criteriaBetween',
  CRITERIA_IN: 'criteriaIn',
}

export const FILTER_MAPPER = {
  alertStatus: 'ALERT_STATUS',
  alertType: 'ALERT_TYPE',
  rule: 'RULE',
  ruleVersion: 'RULE_VERSION',
  transactionType: 'TXN_TYPE',
  network: 'NETWORK',
  region: 'REGION',
  actionDescription: 'ACTN_DESC',
  alertGenerationDate: 'ALERT_GEN_DT',
  oiRiName: 'OI_RI_NAME',
  XBorDOM: 'XB_DOM',
  thresholdPercentage: 'THRESHLD_PRCNT',
  percentageExceeded: 'PRCNT_EXCEEDED',
  thresholdAmount: 'THRESHLD_AMT',
  percentageAmountExceeded: 'PRCNT_AMT_EXCEEDED',
  amountExceeded: 'AMT_EXCEEDED',
  transactionTypeIdentifier: 'TXN_TYP_IDNTFR',
  oiRi: 'OI_RI',
  oiRiCountry: 'OI_RI_COUNTRY',
  oiRiRegion: 'OI_RI_REGION',
  oiRiCid: 'OI_RI_CID',
  fileName: 'FILE_NAME',
}
export const LABEL_MAPPER = {
  alertId: 'Alert ID',
  alertGenerationDate: 'Alert Generation Date',
  alertAge: 'Alert Age',
  alertMonth: 'Alert Month',
  alertYear: 'Alert Year',
  alertStatus: 'Alert Status',
  alertType: 'Alert Type',
  rule: 'Rule',
  ruleVersion: 'Rule Version',
  mccCode: 'MCC code',
  transactionType: 'Transaction Type',
  transactionTypeIdentifier: 'Transaction Type Identifier',
  network: 'Network',
  region: 'Region',
  country: 'Country',
  XbOrDom: 'XB or DOM',
  thresholdPercentage: 'Threshold Percentage',
  percentageExceeded: '% Exceeded',
  thresholdAmount: 'Threshold Amount',
  percentageAmountExceeded: '% Amount Exceeded',
  amountExceeded: 'Amount Exceeded',
  oiRi: 'OI/RI',
  oiRiName: 'OI/RI Name',
  oiRiType: 'OI/RI type',
  oiRiCountry: 'OI/RI Country',
  oiRiRegion: 'OI/RI Region',
  oiRiCid: 'OI/RI CID',
  tIName: 'TI Name',
  fileName: 'File Name',
  action: 'Action',
  actionDescription: 'Action Description',
}
export const TABLE_NAMES = {
  alertList: 'alert-list-table',
}

export const NO_VAL = '-'
export const FILTER_DATE_FORMAT = 'dd-MMM-yyyy'
export const BUTTONS = {
  ADD: 'Add',
  DELETE: 'Delete',
  ADD_COMMENT: 'Add comment',
}

export const SECTIONS = {
  OVERVIEW: 'OVERVIEW',
  COMMENTS: 'COMMENTS',
  ATTACHMENTS: 'ATTACHMENTS',
  HISTORY: 'HISTORY',
}

export const FILTER_LABEL_NAMES = {
  field: 'Field',
  operator: 'Operator',
  value: 'Value',
}

export const FILTER_OPERATOR = {
  CONTAINS: 'CONTAINS',
  EQUAL_TO: 'EQUAL_TO',
  NOT_CONTAINS: 'NOT_CONTAINS',
  BETWEEN: 'BETWEEN',
  NOT_EQUAL_TO: 'NOT_EQUAL_TO',
}

export const FIELD_TYPE = {
  INPUT: 'input',
  DROP_DOWN: 'dropDown',
  DATE_PICKER: 'datePicker',
}

export const SORT_ORDER = {
  ASC: 'ASC',
  DESC: 'DESC',
}

export const EMPTY_TABLE = 'No records found..'

export const GRIP_SCROLLER_TOP = {
  alertDetails: 300,
}
export const GRIP_CLICKER_TOP = {
  alertDetails: 300,
}
export const DEFAULT_FOR_TOP_MENU = {
  alertDetails: 0,
}
export const SCROLL_TIME_TAKEN = 1 * 1000
