export const ROUTES_PATH = {
  alertList: '/alerts',
  alertDetails: '/alert-details/:id',
}
