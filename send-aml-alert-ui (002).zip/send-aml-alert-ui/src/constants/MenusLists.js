export const menuItems = [
  {
    header: 'Alerts',
    url: '/alerts',
    isActive: true,
    subPaths: ['alerts'],
  },
]
