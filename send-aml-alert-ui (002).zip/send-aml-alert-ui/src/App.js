import { Suspense } from 'react'
import './App.css'
import { createBrowserHistory } from 'history'
import GlobalHeader from '@connect/global-header'
import GlobalFooter from '@connect/global-footer'
import ApplicationHeader from './components/ApplicationHeader'
import { internalRoutes } from './routes'
import { Redirect, Route, Router, Switch } from 'react-router-dom'
import { LayoutGroup } from '@connect/layout'
import { getPrefix } from './utils/utility'

const history = createBrowserHistory({ basename: getPrefix() })

const App = () => {
  return (
    <div className="App" data-testid="app-main-wrapper">
      <GlobalHeader></GlobalHeader>
      <LayoutGroup>
        <Suspense fallback={<div>SEND initializing...</div>}>
          <Router history={history}>
            <ApplicationHeader />
            <div
              className="app-content-wrapper"
              data-testid="app-content-wrapper"
            >
              <Switch>
                {internalRoutes.map(
                  ({ key, path, crumbs, renderComponent }) => {
                    return (
                      <Route key={key} path={path}>
                        <div className="all-page-container">
                          {renderComponent(crumbs)}
                        </div>
                      </Route>
                    )
                  }
                )}
                <Redirect exact from="/" to="/alerts" />
              </Switch>
            </div>
          </Router>
        </Suspense>
      </LayoutGroup>
      <GlobalFooter></GlobalFooter>
    </div>
  )
}

export default App
