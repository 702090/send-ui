import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'

const initialState = {
  data: [],
  loading: false,
}

export const getComments = createAsyncThunk(
  'getComments',
  async (alertId, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(`/alerts/${alertId}/comments`)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const addNewComment = createAsyncThunk(
  'addNewComment',
  async ({ payload }, { rejectWithValue }) => {
    try {
      return await clientWrapper.post(`/alerts/comments`, {}, payload, false)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)

export const CommentsSlice = createSlice({
  name: 'comments',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getComments.pending, (state) => {
      state.loading = true
    })
    builder.addCase(getComments.rejected, (state) => {
      state.data = []
      state.error = 'Failed to get comments'
      state.loading = false
    })
    builder.addCase(getComments.fulfilled, (state, { payload }) => {
      state.data = payload
      state.loading = false
    })
    builder.addCase(addNewComment.pending, (state) => {
      state.loading = true
    })
    builder.addCase(addNewComment.rejected, (state) => {
      state.loading = false
    })
    builder.addCase(addNewComment.fulfilled, (state) => {
      state.loading = false
    })
  },
})

export default CommentsSlice.reducer
