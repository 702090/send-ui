import { combineReducers } from 'redux'
import { AlertListSlice } from './AlertListSlice'
import FilterSliceReducer from './FilterSlice'
import ToastDetailsSliceReducer from './ToastDetailsSlice'
import HistorySliceReducer from './HistorySlice'
import AlertDetailsSliceReducer from './AlertDetailsSlice'
import CommentsSliceReducer from './CommentsSlice'
import ExportSliceReducer from './ExportSlice'
import AttachmentsSliceReducer from './AttachmentsSlice'

const reducers = combineReducers({
  alertList: AlertListSlice.reducer,
  filters: FilterSliceReducer,
  toastDetails: ToastDetailsSliceReducer,
  history: HistorySliceReducer,
  alertDetails: AlertDetailsSliceReducer,
  comments: CommentsSliceReducer,
  export: ExportSliceReducer,
  attachments: AttachmentsSliceReducer,
})

export default reducers
