import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'

const initialState = {
  data: [],
  error: '',
}

export const getHistory = createAsyncThunk(
  'getHistory',
  async (alertId, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(`/alerts/${alertId}/alert-history`)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const HistorySlice = createSlice({
  name: 'history',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getHistory.rejected, (state) => {
      state.data = []
      state.error = 'Failed to get alert history'
    })
    builder.addCase(getHistory.fulfilled, (state, { payload }) => {
      state.data = payload
      state.error = ''
    })
  },
})

export default HistorySlice.reducer
