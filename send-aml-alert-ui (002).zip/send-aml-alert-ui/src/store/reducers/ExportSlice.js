import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'

const initialState = {
  loading: false,
  error: '',
}

export const exportAllRecords = createAsyncThunk(
  'export',
  async (payload, { rejectWithValue }) => {
    try {
      return await clientWrapper.post(
        '/alerts/export',
        { responseType: 'blob' },
        payload,
        false
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const ExportSlice = createSlice({
  name: 'export',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(exportAllRecords.pending, (state) => {
      state.loading = true
      state.error = ''
    })
    builder.addCase(exportAllRecords.rejected, (state) => {
      state.error = 'Failed to download alerts'
      state.loading = false
    })
    builder.addCase(exportAllRecords.fulfilled, (state) => {
      state.loading = false
      state.error = ''
    })
  },
})

export default ExportSlice.reducer
