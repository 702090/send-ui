import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'

const initialState = {
  data: [],
  loading: false,
}

export const getAttachments = createAsyncThunk(
  'getAttachments',
  async (alertId, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(`/alerts/${alertId}/attachments`)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const addNewAttachment = createAsyncThunk(
  'addNewAttachment',
  async ({ alertId, formData, category }, { rejectWithValue }) => {
    try {
      return await clientWrapper.post(
        `/alerts/${alertId}/attachments?documentTypes=${category}`,
        {},
        formData,
        true
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const editAttachment = createAsyncThunk(
  'editAttachment',
  async ({ alertId, attachmentId, category }, { rejectWithValue }) => {
    try {
      return await clientWrapper.put(
        `/alerts/${alertId}/attachments/${attachmentId}?documentTypes=${category}`,
        {},
        {},
        false
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const deleteAttachments = createAsyncThunk(
  'deleteAttachments',
  async ({ alertId, ids }, { rejectWithValue }) => {
    try {
      return await clientWrapper.delete(
        `/alerts/${alertId}/attachments/delete-many?ids=${ids}`,
        {},
        {},
        false
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const downloadAttachments = createAsyncThunk(
  'downloadAttachments',
  async ({ alertId, id }, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(
        `/alerts/${alertId}/attachments/download?ids=${id}`,
        { responseType: 'blob' }
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const AttachmentsSlice = createSlice({
  name: 'attachments',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getAttachments.pending, (state) => {
      state.loading = true
    })
    builder.addCase(getAttachments.rejected, (state) => {
      state.data = []
      state.error = 'Failed to get attachments'
      state.loading = false
    })
    builder.addCase(getAttachments.fulfilled, (state, { payload }) => {
      state.data = payload
      state.loading = false
    })
    builder.addCase(addNewAttachment.pending, (state) => {
      state.loading = true
    })
    builder.addCase(addNewAttachment.rejected, (state) => {
      state.error = 'Failed to add attachments'
      state.loading = false
    })
    builder.addCase(addNewAttachment.fulfilled, (state) => {
      state.loading = false
    })
    builder.addCase(deleteAttachments.pending, (state) => {
      state.loading = true
    })
    builder.addCase(deleteAttachments.rejected, (state) => {
      state.error = 'Failed to delete attachments'
      state.loading = false
    })
    builder.addCase(deleteAttachments.fulfilled, (state) => {
      state.loading = false
    })
    builder.addCase(editAttachment.pending, (state) => {
      state.loading = true
    })
    builder.addCase(editAttachment.rejected, (state) => {
      state.error = 'Failed to update attachment'
      state.loading = false
    })
    builder.addCase(editAttachment.fulfilled, (state) => {
      state.loading = false
    })
  },
})

export default AttachmentsSlice.reducer
