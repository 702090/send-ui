import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'

const initialState = {
  data: {},
  loading: false,
}

export const getAlertDetails = createAsyncThunk(
  'getAlertDetails',
  async (alertId, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(`/alerts/${alertId}/alert-details`)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const AlertDetailsSlice = createSlice({
  name: 'alertDetails',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getAlertDetails.pending, (state) => {
      state.loading = true
    })
    builder.addCase(getAlertDetails.rejected, (state) => {
      state.data = {}
      state.loading = false
    })
    builder.addCase(getAlertDetails.fulfilled, (state, { payload }) => {
      state.data = payload
      state.loading = false
    })
  },
})

export default AlertDetailsSlice.reducer
