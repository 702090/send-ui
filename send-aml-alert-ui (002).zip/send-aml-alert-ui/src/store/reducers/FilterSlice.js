import { createSlice } from '@reduxjs/toolkit'
import { filterRow } from '../../components/Filter/FilterConfig'

export const FilterSlice = createSlice({
  name: 'filter',
  initialState: {
    filtersData: [{ ...filterRow }],
    isFilterApplied: false,
  },
  reducers: {
    setFilterData: (state, action) => {
      state.filtersData = action.payload.filtersData
      state.isFilterApplied = action.payload.isFilterApplied
    },
  },
})

export const { setFilterData } = FilterSlice.actions
export default FilterSlice.reducer
