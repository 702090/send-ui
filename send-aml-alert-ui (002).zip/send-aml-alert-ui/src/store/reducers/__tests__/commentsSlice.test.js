import { getComments, addNewComment } from '../CommentsSlice'
import store from '../../index'
import { clientWrapper } from '../../../helper/clientWrapper'

jest.mock('../../../helper/clientWrapper')

describe('Comments Slice test cases', () => {
  it('getComments should dispatch the correct actions on success', async () => {
    clientWrapper.get.mockResolvedValueOnce([])
    const result = await store.dispatch(getComments({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('getComments/fulfilled')
  })
  it('getComments should dispatch the correct actions on failure', async () => {
    clientWrapper.get.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(getComments({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('getComments/rejected')
  })
  it('addNewComment should dispatch the correct actions on success', async () => {
    clientWrapper.post.mockResolvedValueOnce([])
    const result = await store.dispatch(addNewComment({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('addNewComment/fulfilled')
  })
  it('addNewComment should dispatch the correct actions on failure', async () => {
    clientWrapper.post.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(addNewComment({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('addNewComment/rejected')
  })
})
