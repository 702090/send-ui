import { setToastDetails, resetToastDetails } from '../ToastDetailsSlice'
import store from '../../index'
import { ToastVariant } from '@connect/toast'

describe('ToastDetailsSlice test cases', () => {
  it('setToastDetails should dispatch the correct actions on success', async () => {
    await store.dispatch(
      setToastDetails({
        type: ToastVariant.Success,
        message: 'Sample Toast Message',
        duration: 1000,
        visible: true,
      })
    )
    const { toastDetails } = store.getState()
    expect(toastDetails.message).toEqual('Sample Toast Message')
  })
  it('setToastDetails should dispatch the correct actions on success', async () => {
    await store.dispatch(resetToastDetails())
    const { toastDetails } = store.getState()
    expect(toastDetails.message).toEqual('')
  })
})
