import { getAlertDetails } from '../AlertDetailsSlice'
import store from '../../index'
import { clientWrapper } from '../../../helper/clientWrapper'

jest.mock('../../../helper/clientWrapper')

describe('History Slice test cases', () => {
  it('getHistory should dispatch the correct actions on success', async () => {
    clientWrapper.get.mockResolvedValueOnce({})
    const result = await store.dispatch(
      getAlertDetails({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('getAlertDetails/fulfilled')
  })
  it('getHistory should dispatch the correct actions on failure', async () => {
    clientWrapper.get.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(
      getAlertDetails({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('getAlertDetails/rejected')
  })
})
