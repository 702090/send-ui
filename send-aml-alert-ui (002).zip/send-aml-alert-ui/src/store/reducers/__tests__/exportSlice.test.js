import { exportAllRecords } from '../ExportSlice'
import store from '../../index'
import { clientWrapper } from '../../../helper/clientWrapper'

jest.mock('../../../helper/clientWrapper')

describe('Comments Slice test cases', () => {
  it('exportAllRecords should dispatch the correct actions on success', async () => {
    clientWrapper.post.mockResolvedValueOnce(new Blob())
    const result = await store.dispatch(exportAllRecords())
    expect(result.type).toEqual('export/fulfilled')
  })
  it('exportAllRecords should dispatch the correct actions on failure', async () => {
    clientWrapper.post.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(exportAllRecords())
    expect(result.type).toEqual('export/rejected')
  })
})
