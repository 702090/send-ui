import {
  getAttachments,
  addNewAttachment,
  deleteAttachments,
  editAttachment,
} from '../AttachmentsSlice'
import store from '../../index'
import { clientWrapper } from '../../../helper/clientWrapper'

jest.mock('../../../helper/clientWrapper')

describe('Attachments Slice test cases', () => {
  it('getAttachments should dispatch the correct actions on success', async () => {
    clientWrapper.get.mockResolvedValueOnce([])
    const result = await store.dispatch(getAttachments({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('getAttachments/fulfilled')
  })
  it('getAttachments should dispatch the correct actions on failure', async () => {
    clientWrapper.get.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(getAttachments({ alertId: 'SEN-2346' }))
    expect(result.type).toEqual('getAttachments/rejected')
  })
  it('addNewAttachment should dispatch the correct actions on success', async () => {
    clientWrapper.post.mockResolvedValueOnce([])
    const result = await store.dispatch(
      addNewAttachment({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('addNewAttachment/fulfilled')
  })
  it('addNewAttachment should dispatch the correct actions on failure', async () => {
    clientWrapper.post.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(
      addNewAttachment({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('addNewAttachment/rejected')
  })
  it('deleteAttachments should dispatch the correct actions on success', async () => {
    clientWrapper.delete.mockResolvedValueOnce([])
    const result = await store.dispatch(
      deleteAttachments({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('deleteAttachments/fulfilled')
  })
  it('deleteAttachments should dispatch the correct actions on failure', async () => {
    clientWrapper.delete.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(
      deleteAttachments({ alertId: 'SEN-2346' })
    )
    expect(result.type).toEqual('deleteAttachments/rejected')
  })
  it('editAttachment should dispatch the correct actions on success', async () => {
    clientWrapper.post.mockResolvedValueOnce({})
    const result = await store.dispatch(
      editAttachment({ alertId: 'SEN-2346', attachmentId: '1234', category: 'ACTION_PLAN' })
    )
    expect(result.type).toEqual('editAttachment/fulfilled')
  })
  it('editAttachment should dispatch the correct actions on failure', async () => {
    clientWrapper.post.mockRejectedValueOnce({ error: 'error' })
    const result = await store.dispatch(
      editAttachment()
    )
    expect(result.type).toEqual('editAttachment/rejected')
  })
})
