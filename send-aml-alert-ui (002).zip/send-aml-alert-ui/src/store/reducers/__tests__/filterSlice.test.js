import { setFilterData } from '../FilterSlice'
import store from '../../index'

describe('FilterSlice test cases', () => {
  it('setFilterData should dispatch the correct actions on success', async () => {
    await store.dispatch(
      setFilterData({ filterData: [], isFilterApplied: true })
    )
    const filters = store.getState().filters
    expect(filters.isFilterApplied).toEqual(true)
  })
})
