import {
  getAlertList,
  toggleAlertCheckbox,
  resetColumns,
  setCurrentAction,
} from '../AlertListSlice'
import store from '../../index'
import { clientWrapper } from '../../../helper/clientWrapper'
import alertList from '../../../__mocks__/alertList.json'

jest.mock('../../../helper/clientWrapper')

describe('alertDetailsSlice test cases', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })
  it('getAlertList should dispatch the correct actions on success', async () => {
    clientWrapper.post.mockResolvedValueOnce(alertList)
    const result = await store.dispatch(
      getAlertList('GRIP-AL-168-590-370-247-2678')
    )
    expect(result.type).toEqual('getAlertList/fulfilled')
    const list = store.getState().alertList
    expect(list.loading).toEqual(false)
  })
  it('getAlertList should dispatch the correct actions on failure', async () => {
    clientWrapper.post.mockRejectedValueOnce({ error: 'error' })
    await store.dispatch(getAlertList('GRIP-AL-168-590-370-247-2678'))
    const state = store.getState().alertList
    expect(state.loading).toEqual(false)
  })
  it('toggleAlertCheckbox test case', async () => {
    await store.dispatch(toggleAlertCheckbox('alertType'))
    const state = store.getState().alertList
    expect(state.loading).toEqual(false)
  })
  it('setCurrentAction test case', async () => {
    await store.dispatch(setCurrentAction('columns'))
    const state = store.getState().alertList
    expect(state.loading).toEqual(false)
  })
  it('resetColumns test case', async () => {
    await store.dispatch(resetColumns())
    const state = store.getState().alertList
    expect(state.loading).toEqual(false)
  })
})
