import { createSlice } from '@reduxjs/toolkit'

export const ToastDetailsSlice = createSlice({
  name: 'ToastDetails',
  initialState: {
    type: 'neutral',
    message: '',
    duration: 0,
    visible: false,
  },
  reducers: {
    setToastDetails: (state, action) => {
      state.type = action.payload.type
      state.message = action.payload.message
      state.duration = action.payload.duration
      state.visible = action.payload.visible
    },
    resetToastDetails: (state) => {
      state.type = 'neutral'
      state.message = ''
      state.duration = 0
      state.visible = false
    },
  },
})

export const { setToastDetails, resetToastDetails } = ToastDetailsSlice.actions
export default ToastDetailsSlice.reducer
