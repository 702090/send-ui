import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { clientWrapper } from '../../helper/clientWrapper'
import { defaultAlertListColDef } from '../../utils/columnDefinitions'

export const initialState = {
  details: {
    items: [],
    pageLength: 10,
    pageOffset: 0,
    sortField: 'CREATED_ON_DATE',
    sortOrder: 'DESC',
  },
  loading: false,
  columns: defaultAlertListColDef,
  initColumns: defaultAlertListColDef,
  currentAction: 'filter',
}

export const AlertListSlice = createSlice({
  name: 'alertListSlice',
  initialState,
  reducers: {
    updateColumns: (state, action) => {
      return {
        ...state,
        columns: action.payload,
        initColumns: action.payload,
      }
    },
    toggleAlertCheckbox: (state, action) => {
      return {
        ...state,
        columns: [...state.columns].map((coldef) => {
          if (coldef.itemKey !== action.payload) {
            return coldef
          }
          return {
            ...coldef,
            hidden: !coldef.hidden,
          }
        }),
      }
    },
    resetColumns: (state) => {
      return {
        ...state,
        columns: state.initColumns,
      }
    },
    setCurrentAction: (state, action) => {
      return {
        ...state,
        currentAction: action.payload,
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAlertList.pending, (state) => {
        state.loading = true
      })
      .addCase(getAlertList.fulfilled, (state, { payload }) => {
        state.details = payload
        state.loading = false
      })
      .addCase(getAlertList.rejected, (state) => {
        state.loading = false
      })
  },
})
export const downloadAlertFile = createAsyncThunk(
  'downloadAttachments',
  async ({ fileName }, { rejectWithValue }) => {
    try {
      return await clientWrapper.get(
        `/alerts/transaction-details/${fileName}/download`,
        { responseType: 'blob' }
      )
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const getAlertList = createAsyncThunk(
  'getAlertList',
  async (payload, { rejectWithValue }) => {
    try {
      return await clientWrapper.post('/alerts/search', {}, payload, false)
    } catch (error) {
      return rejectWithValue(error.message)
    }
  }
)
export const {
  toggleAlertCheckbox,
  resetColumns,
  setCurrentAction,
  updateColumns,
} = AlertListSlice.actions

export default AlertListSlice.reducer
