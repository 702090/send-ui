import { getFullUrl, downloadFile } from '../utils/utility'

const client = async ({
  endpoint,
  customConfig = {},
  isStaticContent = false,
  headers = {
    'Content-Type': 'application/json',
  },
}) => {
  const config = {
    ...customConfig,
    headers: {
      ...headers,
      ...customConfig.headers,
    },
  }
  if (customConfig.headers === 'form-data') {
    delete config.headers
  }
  let fullUrl = getFullUrl(endpoint)
  if (isStaticContent) {
    fullUrl = `${process.env.REACT_APP_AEM_ENDPOINT}${endpoint}`
  }
  return fetch(fullUrl, config)
    .then(async (response) => {
      if (response.status === 204) {
        return Promise.resolve('Request successful')
      }

      if (response.ok) {
        return handleResponse(response)
      } else {
        return handleErrorResponse(response)
      }
    })
    .catch((error) => {
      return Promise.reject(error)
    })
}

const handleErrorResponse = async (response) => {
  try {
    const res = await response.json()
    return Promise.reject(new Error(res?.errors?.[0]?.description))
  } catch (e) {
    return Promise.reject(new Error('Unknown Error!'))
  }
}

const handleResponse = async (response) => {
  if (response.status === 201) {
    try {
      const res = await response.json()
      return Promise.resolve(res)
    } catch (e) {
      return Promise.resolve('Request successful')
    }
  } else {
    const contentType = response.headers.get('content-type')
    if (contentType && contentType.indexOf('text/html') !== -1) {
      const errorElement = await Promise.resolve(response.text())
      const tempDocument = new DOMParser().parseFromString(
        errorElement,
        'text/html'
      )
      const errorMessage = tempDocument?.body?.textContent
        ?.replace('Regards', ' Regards')
        ?.replace('MasterCard', ' Mastercard')
      return Promise.reject({ message: errorMessage })
    } else if (contentType.includes('excel')) {
      downloadFile(new Blob([response.body]))
    } else if (response.url.includes('attachments/download')) {
      const res = await response.json()
      downloadFile(new Blob([res[0].documentContent]), res[0].documentName)
    } else {
      try {
        const res = await response.json()
        return Promise.resolve(res)
      } catch (e) {
        return Promise.resolve('Request successful')
      }
    }
  }
}

export default client
