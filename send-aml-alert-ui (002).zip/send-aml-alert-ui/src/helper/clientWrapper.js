import client from './client'

const get = (url, requestOptions, applicationName) => {
  if (typeof url !== 'string') {
    url = url.toString()
  }
  const customConfig = {
    method: 'GET',
    ...requestOptions,
  }
  return client({ endpoint: url, customConfig, applicationName })
}

const post = (
  url,
  requestOptions,
  body,
  isFormData = false,
  applicationName
) => {
  // body
  const customConfig = {
    method: 'POST',
    ...requestOptions,
  }
  const headers = {}
  if (!isFormData) {
    headers['Content-Type'] = 'application/json'
  }
  if (body) {
    customConfig.body = isFormData ? body : JSON.stringify(body)
  }
  if (typeof url !== 'string') {
    url = url.toString()
  }
  return client({ endpoint: url, customConfig, applicationName, headers })
}

const put = (url, requestOptions, body, applicationName, isPlain = false) => {
  // body
  const customConfig = {
    method: 'PUT',
    ...requestOptions,
  }
  if (body) {
    customConfig.body = isPlain ? body : JSON.stringify(body)
  }
  if (typeof url !== 'string') {
    url = url.toString()
  }
  return client({ endpoint: url, customConfig, applicationName })
}

const _delete = (url, requestOptions, body, applicationName) => {
  // body
  const customConfig = {
    method: 'DELETE',
    ...requestOptions,
  }
  if (body) {
    customConfig.body = JSON.stringify(body)
  }
  if (typeof url !== 'string') {
    url = url.toString()
  }
  return client({ endpoint: url, customConfig, applicationName })
}

export const clientWrapper = {
  get,
  post,
  put,
  delete: _delete,
}
