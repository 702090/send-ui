import { clientWrapper } from '../clientWrapper'
import '@testing-library/jest-dom'
import { enableFetchMocks } from 'jest-fetch-mock'
import alertList from '../../__mocks__/alertList.json'
import * as errors from '../../constants/AppErrors'
import * as routes from '../../constants/ApiRoutes'
enableFetchMocks()

describe('testing client wrapper', () => {
  errors, routes
  const body = {
    caseId: '',
  }
  const requestOptions = {
    headers: {
      'content-type': 'application/json',
    },
  }
  beforeEach(() => {
    fetch.resetMocks()
    fetch.mockClear()
  })
  it('Client Wrapper GET Method', () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.get('/alertList')
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper GET Method if url is not a string', () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.get(12345)
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method', () => {
    jest.spyOn(clientWrapper, 'post')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.post('/alertList')
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method if url is not a string', () => {
    jest.spyOn(clientWrapper, 'post')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.post(12345)
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method with body', () => {
    jest.spyOn(clientWrapper, 'post')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.post(
      '/alert',
      { ...requestOptions },
      body
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method with body and html response', () => {
    jest.spyOn(clientWrapper, 'post')
    const blob = new Blob([], {
      type: 'text/html',
    })
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        ok: 'ok',
        text: () => blob,
        headers: { get: jest.fn(() => 'text/html') },
      })
    )
    const clientResponse = clientWrapper.post(
      '/alert',
      { ...requestOptions },
      body
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method with body and json response ', () => {
    jest.spyOn(clientWrapper, 'post')
    const blob = new Blob([], {
      type: 'text/html',
    })
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        ok: 'ok',
        text: () => blob,
        headers: { get: jest.fn(() => 'application/json') },
      })
    )
    const clientResponse = clientWrapper.post(
      '/alert',
      { ...requestOptions },
      body
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper POST Method with body and formData and json response ', () => {
    jest.spyOn(clientWrapper, 'post')
    const blob = new Blob([], {
      type: 'text/html',
    })
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        ok: 'ok',
        text: () => blob,
        headers: { get: jest.fn(() => 'application/json') },
      })
    )
    const clientResponse = clientWrapper.post(
      '/alert',
      { ...requestOptions },
      body,
      true
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper PUT Method', () => {
    jest.spyOn(clientWrapper, 'put')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.put('/cases')
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper PUT Method if url is not a string', () => {
    jest.spyOn(clientWrapper, 'put')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.put(12345)
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper PUT Method with body', () => {
    jest.spyOn(clientWrapper, 'put')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.put(
      '/cases',
      {
        ...requestOptions,
      },
      body
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper PUT Method with body and is plain', () => {
    jest.spyOn(clientWrapper, 'put')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.put(
      '/cases',
      {
        ...requestOptions,
      },
      body,
      'alerts',
      true
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper DELETE Method', () => {
    jest.spyOn(clientWrapper, 'delete')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.delete('/cases')
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper DELETE Method if url is not a string', () => {
    jest.spyOn(clientWrapper, 'delete')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.delete(12345)
    expect(clientResponse).not.toBeNull()
  })

  it('Client Wrapper DELETE Method with body', () => {
    jest.spyOn(clientWrapper, 'delete')
    fetch.mockImplementationOnce(() => Promise.resolve(alertList))
    const clientResponse = clientWrapper.delete(
      '/cases',
      {
        ...requestOptions,
      },
      body
    )
    expect(clientResponse).not.toBeNull()
  })

  it('Should return Forbidden error for unauthorized request', async () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        status: 401,
        json: () => {
          return {
            errors: [
              {
                description: 'Forbidden !!!',
              },
            ],
          }
        },
      })
    )
    let error
    try {
      await clientWrapper.get(12345)
    } catch (err) {
      error = err
    }
    expect(error).toEqual(new Error('Forbidden !!!'))
  })

  it('Should return Forbidden error for unauthorized request', async () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        json: () => {
          return {
            errors: [
              {
                description: 'Forbidden !!!',
              },
            ],
          }
        },
      })
    )
    let error
    try {
      await clientWrapper.get(12345)
    } catch (err) {
      error = err
    }
    expect(error).toEqual(new Error('Forbidden !!!'))
  })

  it('Should return Internal Server Error error for server error', async () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        status: 500,
        json: () => {
          return {
            errors: [
              {
                description: 'Internal Server Error',
              },
            ],
          }
        },
      })
    )
    let error
    try {
      await clientWrapper.get(12345)
    } catch (err) {
      error = err
    }
    expect(error).toEqual(new Error('Internal Server Error'))
  })

  it('Should return Request successful error for status code 204', async () => {
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        status: 204,
      })
    )
    const response = await clientWrapper.get(12345)
    expect(response).toEqual('Request successful')
  })

  it('Should return You are not authorized to perform this action! error for status code 403', async () => {
    jest.spyOn(clientWrapper, 'get')
    const data = {
      data: 'Request if forbidden to access the resource /mcp-stage/bram/cases/api/cases/BRAM-CS-165-218-928-356-7613/service-providers',
    }
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        status: 403,
        json: () => data,
      })
    )
    try {
      await clientWrapper.get(12345)
    } catch (error) {
      expect(error).not.toBeNull()
    }
  })

  it('Should return Request Successful for if response is ok without json', async () => {
    jest.spyOn(clientWrapper, 'get')
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        ok: 'ok',
        status: 201,
      })
    )
    try {
      await clientWrapper.get(12345)
    } catch (error) {
      expect(error).toEqual({
        message: 'Request successful',
      })
    }
  })

  it('Should return Request Successful for if response is ok with json', async () => {
    jest.spyOn(clientWrapper, 'get')
    const data = {
      data: 'successful',
    }
    fetch.mockImplementationOnce(() =>
      Promise.resolve({
        ok: 'ok',
        status: 201,
        json: () => data,
      })
    )
    try {
      await clientWrapper.get(12345)
    } catch (error) {
      expect(error).toEqual({
        message: 'Request successful',
      })
    }
  })
})
