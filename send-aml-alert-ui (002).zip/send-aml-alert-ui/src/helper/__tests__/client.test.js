import client from '../client'

describe('testing client function', () => {
  it('Client main method', () => {
    expect(
      client({
        endpoint: 'https://test-endpoint.com/alerts/list',
      })
    ).resolves.toEqual('Request successful')
  })
  it('Client main method', () => {
    expect(
      client({
        endpoint: 'https://test-endpoint.com/alerts/list',
        customConfig: { headers: '' },
      })
    ).resolves.toEqual('Request successful')
  })
  it('Client main method', () => {
    expect(
      client({ endpoint: 'https://test-endpoint.com/alerts/list' })
    ).resolves.toEqual('Request successful')
  })
  it('Client main method', () => {
    expect(
      client({
        endpoint: 'https://test-endpoint.com/alerts/list',
        customConfig: { headers: 'form-data' },
        isStaticContent: true,
      })
    ).resolves.toEqual('Request successful')
  })
})
